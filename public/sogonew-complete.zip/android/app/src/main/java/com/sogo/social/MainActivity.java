package com.sogo.social;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
