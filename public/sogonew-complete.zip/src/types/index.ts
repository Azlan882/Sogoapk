export interface User {
  id: string;
  username: string;
  displayName: string;
  email?: string;
  avatarUrl: string;
  bio?: string;
  website?: string;
  birthday?: string;
  isOnboarded?: boolean;
  followersCount: number;
  followingCount: number;
  postsCount: number;
  isFollowing?: boolean;
  isVerified?: boolean;
  createdAt: string;
}

export interface Post {
  id: string;
  userId: string;
  user: {
    id: string;
    username: string;
    displayName: string;
    avatarUrl: string;
    isVerified?: boolean;
  };
  imageUrl: string;
  caption: string;
  tags?: string[];
  location?: string;
  likesCount: number;
  commentsCount: number;
  isLiked?: boolean;
  isBookmarked?: boolean;
  createdAt: string;
}

export interface Comment {
  id: string;
  postId: string;
  userId: string;
  user: {
    id: string;
    username: string;
    displayName: string;
    avatarUrl: string;
  };
  text: string;
  createdAt: string;
  likesCount?: number;
  isLiked?: boolean;
}

export interface Story {
  id: string;
  userId: string;
  user: {
    id: string;
    username: string;
    displayName: string;
    avatarUrl: string;
  };
  mediaUrl: string;
  createdAt: string;
  hasSeen?: boolean;
}

export interface NotificationItem {
  id: string;
  type: 'like' | 'comment' | 'follow' | 'mention';
  fromUser: {
    id: string;
    username: string;
    displayName: string;
    avatarUrl: string;
  };
  postId?: string;
  postImageUrl?: string;
  text?: string;
  createdAt: string;
  read: boolean;
}

export interface VideoPost {
  id: string;
  userId: string;
  user: {
    id: string;
    username: string;
    displayName: string;
    avatarUrl: string;
    isVerified?: boolean;
  };
  videoUrl: string;
  thumbnailUrl: string;
  caption: string;
  tags?: string[];
  likesCount: number;
  commentsCount: number;
  viewsCount: number;
  isLiked?: boolean;
  createdAt: string;
  duration?: number;
}

export interface VideoComment {
  id: string;
  videoId: string;
  userId: string;
  user: {
    id: string;
    username: string;
    displayName: string;
    avatarUrl: string;
  };
  text: string;
  createdAt: string;
}

export type ActiveTab = 'home' | 'discover' | 'videos' | 'create' | 'bookmarks' | 'notifications' | 'profile';
