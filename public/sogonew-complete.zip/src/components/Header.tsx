import React from 'react';
import { Bell, Bookmark, PlusSquare, Search, Film } from 'lucide-react';
import { ActiveTab } from '../types';
import { useAuth } from '../hooks/useAuth';
import { Avatar } from './Avatar';
import sogoLogo from '../assets/sogo-mark.svg';

export interface HeaderProps {
  currentTab: ActiveTab;
  onTabChange: (tab: ActiveTab) => void;
  unreadNotificationsCount?: number;
}

export const Header: React.FC<HeaderProps> = ({
  onTabChange,
  unreadNotificationsCount = 2,
}) => {
  const { currentUser } = useAuth();

  return (
    <header className="sticky top-0 z-30 bg-[#0F172A]/90 backdrop-blur-md border-b border-slate-800 transition-all">
      <div className="max-w-4xl mx-auto px-4 h-14 flex items-center justify-between">
        {/* Logo */}
        <button
          type="button"
          onClick={() => onTabChange('home')}
          className="flex items-center gap-2.5 focus:outline-none group cursor-pointer"
        >
          <img
            src={sogoLogo}
            alt="Sogo"
            className="w-9 h-9 object-contain drop-shadow-md group-hover:scale-105 transition-transform"
          />
          <span className="font-extrabold text-xl tracking-tight bg-gradient-to-r from-pink-400 via-purple-400 to-cyan-400 bg-clip-text text-transparent">
            Sogo
          </span>
        </button>

        {/* Desktop / Tablet Quick Actions */}
        <div className="flex items-center gap-1 sm:gap-2">
          <button
            type="button"
            onClick={() => onTabChange('videos')}
            className="p-2 text-slate-400 hover:text-cyan-400 rounded-xl hover:bg-slate-800/80 transition-colors focus:outline-none cursor-pointer"
            aria-label="Reels"
          >
            <Film className="w-5 h-5" />
          </button>

          <button
            type="button"
            onClick={() => onTabChange('discover')}
            className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800/80 transition-colors focus:outline-none cursor-pointer"
            aria-label="Discover"
          >
            <Search className="w-5 h-5" />
          </button>

          <button
            type="button"
            onClick={() => onTabChange('create')}
            className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-400 font-semibold text-xs rounded-xl border border-cyan-500/30 transition-colors focus:outline-none"
          >
            <PlusSquare className="w-4 h-4" />
            <span>Create</span>
          </button>

          <button
            type="button"
            onClick={() => onTabChange('bookmarks')}
            className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800/80 transition-colors focus:outline-none hidden sm:block"
            aria-label="Saved Bookmarks"
          >
            <Bookmark className="w-5 h-5" />
          </button>

          <button
            type="button"
            onClick={() => onTabChange('notifications')}
            className="relative p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800/80 transition-colors focus:outline-none"
            aria-label="Notifications"
          >
            <Bell className="w-5 h-5" />
            {unreadNotificationsCount > 0 && (
              <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-cyan-400 rounded-full ring-2 ring-[#0F172A] animate-pulse" />
            )}
          </button>

          {currentUser ? (
            <div className="ml-1 hidden sm:block">
              <Avatar
                src={currentUser.avatarUrl}
                alt={currentUser.displayName}
                size="sm"
                onClick={() => onTabChange('profile')}
              />
            </div>
          ) : (
            <button
              type="button"
              onClick={() => onTabChange('profile')}
              className="ml-1 hidden sm:flex items-center px-3 py-1 text-xs font-semibold text-cyan-400 border border-cyan-500/40 rounded-xl hover:bg-cyan-500/10 transition-colors cursor-pointer"
            >
              Sign In
            </button>
          )}
        </div>
      </div>
    </header>
  );
};
