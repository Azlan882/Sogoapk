import React from 'react';
import { Post } from '../types';
import { Heart, MessageCircle } from 'lucide-react';
import { formatNumber } from '../lib/utils';

export interface ImageGridProps {
  posts: Post[];
  onPostClick: (post: Post) => void;
  emptyMessage?: string;
}

export const ImageGrid: React.FC<ImageGridProps> = ({ posts, onPostClick, emptyMessage = 'No posts yet' }) => {
  if (posts.length === 0) {
    return (
      <div className="py-12 text-center text-sm text-slate-500">
        {emptyMessage}
      </div>
    );
  }

  return (
    <div className="grid grid-cols-3 gap-1.5 sm:gap-2.5">
      {posts.map((post) => (
        <div
          key={post.id}
          onClick={() => onPostClick(post)}
          className="group relative aspect-square bg-slate-800 border border-slate-800/80 overflow-hidden cursor-pointer rounded-lg sm:rounded-xl shadow-xs"
        >
          <img
            src={post.imageUrl}
            alt={post.caption}
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
            loading="lazy"
          />

          {/* Hover Overlay */}
          <div className="absolute inset-0 bg-[#0B0F1A]/70 backdrop-blur-xs opacity-0 group-hover:opacity-100 transition-opacity duration-200 flex items-center justify-center gap-4 text-white">
            <div className="flex items-center gap-1.5 font-bold text-xs sm:text-sm">
              <Heart className="w-4 h-4 fill-rose-500 text-rose-500" />
              <span>{formatNumber(post.likesCount)}</span>
            </div>
            <div className="flex items-center gap-1.5 font-bold text-xs sm:text-sm">
              <MessageCircle className="w-4 h-4 fill-cyan-400 text-cyan-400" />
              <span>{formatNumber(post.commentsCount)}</span>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};
