import React from 'react';
import { User } from '../types';
import { Avatar } from './Avatar';
import { Button } from './Button';
import { formatNumber } from '../lib/utils';
import { CheckCircle2, Settings, Globe, Edit3 } from 'lucide-react';

export interface ProfileHeaderProps {
  user: User;
  isCurrentUser: boolean;
  onEditProfile?: () => void;
  onFollowToggle?: (userId: string) => void;
  onSettingsClick?: () => void;
}

export const ProfileHeader: React.FC<ProfileHeaderProps> = ({
  user,
  isCurrentUser,
  onEditProfile,
  onFollowToggle,
  onSettingsClick,
}) => {
  return (
    <div className="bg-slate-900 rounded-2xl border border-slate-800 p-5 sm:p-6 mb-6 shadow-sm">
      <div className="flex flex-col sm:flex-row items-start sm:items-center gap-5">
        {/* Avatar */}
        <div className="flex items-center gap-4">
          <Avatar
            src={user.avatarUrl}
            alt={user.displayName}
            size="xl"
            hasStory={false}
          />
        </div>

        {/* Info & Stats */}
        <div className="flex-1 w-full">
          <div className="flex items-center justify-between gap-3 flex-wrap">
            <div>
              <div className="flex items-center gap-1.5">
                <h1 className="text-xl font-bold text-white">{user.displayName}</h1>
                {user.isVerified && (
                  <CheckCircle2 className="w-5 h-5 text-cyan-400 fill-cyan-400/20 shrink-0" />
                )}
              </div>
              <p className="text-sm text-slate-400">@{user.username}</p>
            </div>

            {/* Action Buttons */}
            <div className="flex items-center gap-2">
              {isCurrentUser ? (
                <>
                  <Button
                    variant="secondary"
                    size="sm"
                    leftIcon={<Edit3 className="w-4 h-4" />}
                    onClick={onEditProfile}
                  >
                    Edit Profile
                  </Button>
                  <button
                    type="button"
                    onClick={onSettingsClick}
                    className="p-2 text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-xl transition-colors"
                    aria-label="Settings"
                  >
                    <Settings className="w-4 h-4" />
                  </button>
                </>
              ) : (
                <Button
                  variant={user.isFollowing ? 'secondary' : 'primary'}
                  size="sm"
                  onClick={() => onFollowToggle?.(user.id)}
                >
                  {user.isFollowing ? 'Following' : 'Follow'}
                </Button>
              )}
            </div>
          </div>

          {/* Bio & Link */}
          {user.bio && (
            <p className="text-sm text-slate-300 mt-3 leading-relaxed max-w-xl">
              {user.bio}
            </p>
          )}

          {user.website && (
            <a
              href={user.website}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 text-xs font-semibold text-cyan-400 hover:underline mt-2"
            >
              <Globe className="w-3.5 h-3.5" />
              <span>{user.website.replace(/^https?:\/\//, '')}</span>
            </a>
          )}

          {/* Numerical Stats */}
          <div className="flex items-center gap-6 mt-4 pt-4 border-t border-slate-800">
            <div className="text-center sm:text-left">
              <span className="block text-base font-bold text-white">
                {formatNumber(user.postsCount)}
              </span>
              <span className="text-xs text-slate-500">Posts</span>
            </div>
            <div className="text-center sm:text-left">
              <span className="block text-base font-bold text-white">
                {formatNumber(user.followersCount)}
              </span>
              <span className="text-xs text-slate-500">Followers</span>
            </div>
            <div className="text-center sm:text-left">
              <span className="block text-base font-bold text-white">
                {formatNumber(user.followingCount)}
              </span>
              <span className="text-xs text-slate-500">Following</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
