import React from 'react';
import { Story } from '../types';
import { Avatar } from './Avatar';

export interface StoryItemProps {
  story: Story;
  onClick: (story: Story) => void;
}

export const StoryItem: React.FC<StoryItemProps> = ({ story, onClick }) => {
  return (
    <button
      type="button"
      onClick={() => onClick(story)}
      className="flex flex-col items-center gap-1.5 focus:outline-none group cursor-pointer shrink-0"
    >
      <Avatar
        src={story.user.avatarUrl}
        alt={story.user.displayName}
        size="lg"
        hasStory={true}
        storySeen={story.hasSeen}
      />
      <span className="text-xs font-medium text-slate-300 max-w-[68px] truncate group-hover:text-cyan-400">
        {story.user.username}
      </span>
    </button>
  );
};
