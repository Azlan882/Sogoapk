import React from 'react';
import { Home, Compass, PlusSquare, User, Film } from 'lucide-react';
import { ActiveTab } from '../types';
import { cn } from '../lib/utils';
import { useAuth } from '../hooks/useAuth';
import { Avatar } from './Avatar';

export interface BottomNavigationProps {
  currentTab: ActiveTab;
  onTabChange: (tab: ActiveTab) => void;
}

export const BottomNavigation: React.FC<BottomNavigationProps> = ({ currentTab, onTabChange }) => {
  const { currentUser } = useAuth();

  const navItems = [
    { id: 'home' as ActiveTab, label: 'Home', icon: Home },
    { id: 'discover' as ActiveTab, label: 'Discover', icon: Compass },
    { id: 'create' as ActiveTab, label: 'Create', icon: PlusSquare, isSpecial: true },
    { id: 'videos' as ActiveTab, label: 'Reels', icon: Film },
    { id: 'profile' as ActiveTab, label: 'Profile', icon: User, isProfile: true },
  ];

  return (
    <nav className="fixed bottom-0 inset-x-0 z-30 bg-[#0F172A]/95 backdrop-blur-md border-t border-slate-800 px-3 py-1.5 sm:py-2">
      <div className="max-w-md mx-auto flex items-center justify-around">
        {navItems.map((item) => {
          const isActive = currentTab === item.id;
          const IconComponent = item.icon;

          if (item.isSpecial) {
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => onTabChange(item.id)}
                className="flex flex-col items-center justify-center -mt-4 focus:outline-none group cursor-pointer"
                aria-label="Create Post"
              >
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-cyan-400 to-blue-600 shadow-lg shadow-cyan-500/25 flex items-center justify-center text-slate-950 group-hover:scale-105 active:scale-95 transition-transform">
                  <IconComponent className="w-6 h-6 stroke-[2.5px]" />
                </div>
              </button>
            );
          }

          if (item.isProfile && currentUser) {
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => onTabChange(item.id)}
                className="flex flex-col items-center justify-center p-1.5 focus:outline-none group cursor-pointer"
                aria-label="Profile"
              >
                <div
                  className={cn(
                    'p-0.5 rounded-full transition-all',
                    isActive ? 'ring-2 ring-cyan-400' : 'opacity-70 group-hover:opacity-100'
                  )}
                >
                  <Avatar
                    src={currentUser.avatarUrl}
                    alt={currentUser.displayName}
                    size="xs"
                  />
                </div>
                <span
                  className={cn(
                    'text-[10px] mt-1 font-medium transition-colors',
                    isActive ? 'text-cyan-400 font-bold' : 'text-slate-400 group-hover:text-slate-200'
                  )}
                >
                  {item.label}
                </span>
              </button>
            );
          }

          return (
            <button
              key={item.id}
              type="button"
              onClick={() => onTabChange(item.id)}
              className="flex flex-col items-center justify-center p-1.5 focus:outline-none group cursor-pointer"
              aria-label={item.label}
            >
              <IconComponent
                className={cn(
                  'w-5 h-5 transition-transform duration-150',
                  isActive
                    ? 'text-cyan-400 stroke-[2.5px] scale-105'
                    : 'text-slate-400 group-hover:text-slate-200'
                )}
              />
              <span
                className={cn(
                  'text-[10px] mt-1 font-medium transition-colors',
                  isActive ? 'text-cyan-400 font-bold' : 'text-slate-400 group-hover:text-slate-200'
                )}
              >
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
