import React, { useState } from 'react';
import { Post } from '../types';
import { Avatar } from './Avatar';
import { PostActions } from './PostActions';
import { timeAgo, formatNumber } from '../lib/utils';
import { CheckCircle2, MoreHorizontal, MapPin, Heart } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export interface PostCardProps {
  post: Post;
  onLike: (postId: string) => void;
  onBookmark: (postId: string) => void;
  onCommentClick: (post: Post) => void;
  onUserClick?: (userId: string) => void;
  onShare?: (post: Post) => void;
  onQuickComment?: (postId: string, text: string) => void;
}

export const PostCard: React.FC<PostCardProps> = ({
  post,
  onLike,
  onBookmark,
  onCommentClick,
  onUserClick,
  onShare,
  onQuickComment,
}) => {
  const [showHeartOverlay, setShowHeartOverlay] = useState(false);
  const [commentInput, setCommentInput] = useState('');
  const [isExpanded, setIsExpanded] = useState(false);

  const handleDoubleTap = () => {
    if (!post.isLiked) {
      onLike(post.id);
    }
    setShowHeartOverlay(true);
    setTimeout(() => setShowHeartOverlay(false), 800);
  };

  const handleCommentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentInput.trim()) return;
    onQuickComment?.(post.id, commentInput.trim());
    setCommentInput('');
  };

  return (
    <article className="bg-slate-900 rounded-2xl border border-slate-800 shadow-sm overflow-hidden mb-6 transition-all hover:border-slate-700">
      {/* Post Header */}
      <div className="flex items-center justify-between p-3.5 sm:p-4">
        <div className="flex items-center gap-3">
          <Avatar
            src={post.user.avatarUrl}
            alt={post.user.displayName}
            size="md"
            onClick={() => onUserClick?.(post.user.id)}
          />
          <div className="flex flex-col">
            <div className="flex items-center gap-1.5">
              <button
                type="button"
                onClick={() => onUserClick?.(post.user.id)}
                className="font-bold text-sm text-white hover:underline flex items-center gap-1 focus:outline-none"
              >
                <span>{post.user.displayName}</span>
                {post.user.isVerified && (
                  <CheckCircle2 className="w-4 h-4 text-cyan-400 fill-cyan-400/20 shrink-0" />
                )}
              </button>
              <span className="text-xs text-slate-400">@{post.user.username}</span>
            </div>
            {post.location && (
              <div className="flex items-center gap-1 text-[11px] text-slate-400 mt-0.5">
                <MapPin className="w-3 h-3 text-cyan-400 shrink-0" />
                <span className="truncate max-w-[200px]">{post.location}</span>
              </div>
            )}
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-500">{timeAgo(post.createdAt)}</span>
          <button
            type="button"
            className="p-1.5 text-slate-400 hover:text-slate-200 rounded-lg hover:bg-slate-800 transition-colors"
            aria-label="Post options"
          >
            <MoreHorizontal className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Post Media (Image) with Double-Tap Heart Animation */}
      <div
        className="relative aspect-4/3 sm:aspect-16/10 bg-neutral-900 cursor-pointer select-none overflow-hidden"
        onDoubleClick={handleDoubleTap}
      >
        <img
          src={post.imageUrl}
          alt={post.caption}
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover transition-transform duration-300 hover:scale-[1.01]"
          loading="lazy"
        />

        {/* Double-tap Heart Animation */}
        <AnimatePresence>
          {showHeartOverlay && (
            <motion.div
              initial={{ scale: 0, opacity: 0 }}
              animate={{ scale: 1.2, opacity: 0.95 }}
              exit={{ scale: 1.4, opacity: 0 }}
              transition={{ duration: 0.4 }}
              className="absolute inset-0 flex items-center justify-center pointer-events-none"
            >
              <Heart className="w-24 h-24 text-white fill-rose-500 drop-shadow-xl" />
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Interactive Actions */}
      <div className="px-3.5 sm:px-4 pt-1">
        <PostActions
          isLiked={post.isLiked}
          likesCount={post.likesCount}
          commentsCount={post.commentsCount}
          isBookmarked={post.isBookmarked}
          onLike={() => onLike(post.id)}
          onComment={() => onCommentClick(post)}
          onBookmark={() => onBookmark(post.id)}
          onShare={() => onShare?.(post)}
        />

        {/* Caption and Tags */}
        <div className="pb-3 text-sm">
          <p className="text-slate-300 leading-relaxed">
            <button
              type="button"
              onClick={() => onUserClick?.(post.user.id)}
              className="font-bold text-white hover:underline mr-1.5 focus:outline-none"
            >
              {post.user.username}
            </button>
            {post.caption.length > 120 && !isExpanded ? (
              <>
                <span>{post.caption.slice(0, 120)}... </span>
                <button
                  type="button"
                  onClick={() => setIsExpanded(true)}
                  className="text-slate-400 font-medium hover:text-cyan-400 text-xs"
                >
                  more
                </button>
              </>
            ) : (
              <span>{post.caption}</span>
            )}
          </p>

          {post.tags && post.tags.length > 0 && (
            <div className="flex flex-wrap gap-1.5 mt-2">
              {post.tags.map((tag) => (
                <span
                  key={tag}
                  className="text-xs text-cyan-400 hover:text-cyan-300 font-medium hover:underline cursor-pointer"
                >
                  #{tag}
                </span>
              ))}
            </div>
          )}

          {/* View Comments Link */}
          {post.commentsCount > 0 && (
            <button
              type="button"
              onClick={() => onCommentClick(post)}
              className="mt-2 text-xs font-medium text-slate-400 hover:text-slate-200 block focus:outline-none"
            >
              View all {post.commentsCount} {post.commentsCount === 1 ? 'comment' : 'comments'}
            </button>
          )}
        </div>

        {/* Quick Comment Input */}
        <form
          onSubmit={handleCommentSubmit}
          className="flex items-center gap-2 py-2.5 border-t border-slate-800"
        >
          <input
            type="text"
            value={commentInput}
            onChange={(e) => setCommentInput(e.target.value)}
            placeholder="Add a comment..."
            className="flex-1 text-xs text-slate-200 placeholder:text-slate-500 bg-transparent focus:outline-none"
          />
          {commentInput.trim() && (
            <button
              type="submit"
              className="text-xs font-bold text-cyan-400 hover:text-cyan-300 focus:outline-none transition-colors"
            >
              Post
            </button>
          )}
        </form>
      </div>
    </article>
  );
};
