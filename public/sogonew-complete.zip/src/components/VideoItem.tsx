import React, { useRef, useState, useEffect } from 'react';
import {
  Heart,
  MessageCircle,
  Share2,
  Volume2,
  VolumeX,
  Play,
  RotateCcw,
  Check,
  Music,
} from 'lucide-react';
import { VideoPost } from '../types';
import { Avatar } from './Avatar';
import { useAuth } from '../hooks/useAuth';
import * as videosService from '../services/videosService';

export interface VideoItemProps {
  video: VideoPost;
  isActive: boolean;
  isMuted: boolean;
  onToggleMute: () => void;
  onUserClick: (userId: string) => void;
  onCommentClick: (video: VideoPost) => void;
  onVideoUpdated?: (video: VideoPost) => void;
}

export const VideoItem: React.FC<VideoItemProps> = ({
  video,
  isActive,
  isMuted,
  onToggleMute,
  onUserClick,
  onCommentClick,
  onVideoUpdated,
}) => {
  const { currentUser } = useAuth();
  const videoRef = useRef<HTMLVideoElement | null>(null);

  const [isPlaying, setIsPlaying] = useState(false);
  const [isLiked, setIsLiked] = useState(video.isLiked ?? false);
  const [likesCount, setLikesCount] = useState(video.likesCount);
  const [commentsCount, setCommentsCount] = useState(video.commentsCount);
  const [isLoading, setIsLoading] = useState(true);
  const [hasError, setHasError] = useState(false);
  const [showPlayIcon, setShowPlayIcon] = useState(false);
  const [showHeartAnim, setShowHeartAnim] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [progressPercent, setProgressPercent] = useState(0);

  // Synchronize internal state when video prop updates
  useEffect(() => {
    setIsLiked(video.isLiked ?? false);
    setLikesCount(video.likesCount);
    setCommentsCount(video.commentsCount);
  }, [video.isLiked, video.likesCount, video.commentsCount]);

  // Autoplay or pause based on isActive
  useEffect(() => {
    const el = videoRef.current;
    if (!el) return;

    if (isActive) {
      setHasError(false);
      const playPromise = el.play();
      if (playPromise !== undefined) {
        playPromise
          .then(() => {
            setIsPlaying(true);
            setIsLoading(false);
          })
          .catch((err) => {
            // Autoplay was blocked or failed
            console.warn('Video autoplay prevented or failed:', err);
            setIsPlaying(false);
          });
      }
    } else {
      el.pause();
      setIsPlaying(false);
    }
  }, [isActive]);

  // Handle Mute state
  useEffect(() => {
    if (videoRef.current) {
      videoRef.current.muted = isMuted;
    }
  }, [isMuted]);

  // Conservative view tracking: only after 3s of active playback
  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (isActive && isPlaying) {
      timer = setTimeout(() => {
        videosService.incrementVideoViews(video.id);
      }, 3000);
    }
    return () => {
      if (timer) clearTimeout(timer);
    };
  }, [isActive, isPlaying, video.id]);

  // Toggle play/pause by tapping the video
  const togglePlayPause = () => {
    const el = videoRef.current;
    if (!el) return;

    if (el.paused) {
      el.play()
        .then(() => setIsPlaying(true))
        .catch(() => setIsPlaying(false));
      setShowPlayIcon(false);
    } else {
      el.pause();
      setIsPlaying(false);
      setShowPlayIcon(true);
    }
  };

  // Double tap to like
  const lastTapRef = useRef<number>(0);
  const handleContainerClick = () => {
    const now = Date.now();
    const DOUBLE_TAP_DELAY = 300;
    if (now - lastTapRef.current < DOUBLE_TAP_DELAY) {
      // Double tap triggered
      if (!isLiked && currentUser) {
        handleLike();
      }
      setShowHeartAnim(true);
      setTimeout(() => setShowHeartAnim(false), 800);
    } else {
      togglePlayPause();
    }
    lastTapRef.current = now;
  };

  const handleLike = async () => {
    if (!currentUser) return;
    // Optimistic UI update
    const nextLiked = !isLiked;
    const nextCount = nextLiked ? likesCount + 1 : Math.max(0, likesCount - 1);
    setIsLiked(nextLiked);
    setLikesCount(nextCount);

    try {
      const res = await videosService.toggleLikeVideo(video.id, currentUser.id);
      setIsLiked(res.isLiked);
      setLikesCount(res.likesCount);
      if (onVideoUpdated) {
        onVideoUpdated({
          ...video,
          isLiked: res.isLiked,
          likesCount: res.likesCount,
        });
      }
    } catch (err) {
      // Rollback on error
      setIsLiked(!nextLiked);
      setLikesCount(likesCount);
    }
  };

  const handleShare = async () => {
    const shareUrl = window.location.href;
    if (navigator.share) {
      try {
        await navigator.share({
          title: `Video by @${video.user.username} on Sogo`,
          text: video.caption || 'Check out this video on Sogo!',
          url: shareUrl,
        });
      } catch {
        // Fallback to clipboard
        copyToClipboard(shareUrl);
      }
    } else {
      copyToClipboard(shareUrl);
    }
  };

  const copyToClipboard = (url: string) => {
    navigator.clipboard.writeText(url);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  const handleTimeUpdate = () => {
    const el = videoRef.current;
    if (el && el.duration) {
      setProgressPercent((el.currentTime / el.duration) * 100);
    }
  };

  return (
    <div
      className="relative w-full h-full snap-start snap-always flex items-center justify-center bg-black overflow-hidden select-none"
      onClick={handleContainerClick}
    >
      {/* Video Element */}
      <video
        ref={videoRef}
        src={video.videoUrl}
        poster={video.thumbnailUrl}
        playsInline
        loop
        muted={isMuted}
        preload={isActive ? 'auto' : 'metadata'}
        onWaiting={() => setIsLoading(true)}
        onPlaying={() => {
          setIsLoading(false);
          setIsPlaying(true);
        }}
        onTimeUpdate={handleTimeUpdate}
        onError={() => {
          setIsLoading(false);
          setHasError(true);
        }}
        className="w-full h-full object-contain sm:object-cover"
      />

      {/* Loading Spinner */}
      {isLoading && !hasError && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/30 pointer-events-none">
          <div className="w-10 h-10 border-3 border-cyan-400 border-t-transparent rounded-full animate-spin" />
        </div>
      )}

      {/* Error / Fallback State */}
      {hasError && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-slate-950/90 text-center px-6">
          <div className="w-12 h-12 rounded-full bg-red-500/20 text-red-400 flex items-center justify-center mb-3">
            <RotateCcw className="w-6 h-6" />
          </div>
          <p className="text-sm font-semibold text-white">Video unavailable</p>
          <p className="text-xs text-slate-400 mt-1 max-w-xs">
            Could not stream the video from Cloudinary.
          </p>
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              setHasError(false);
              setIsLoading(true);
              videoRef.current?.load();
              videoRef.current?.play().catch(() => {});
            }}
            className="mt-4 px-4 py-2 bg-cyan-500 hover:bg-cyan-600 text-slate-950 font-bold text-xs rounded-xl cursor-pointer"
          >
            Retry playback
          </button>
        </div>
      )}

      {/* Big Pause Indicator */}
      {showPlayIcon && !isLoading && !hasError && (
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <div className="w-16 h-16 rounded-full bg-black/50 backdrop-blur-sm flex items-center justify-center text-white scale-110 animate-in fade-in zoom-in-75 duration-150">
            <Play className="w-8 h-8 fill-white ml-1" />
          </div>
        </div>
      )}

      {/* Double Tap Heart Pop */}
      {showHeartAnim && (
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-20">
          <Heart className="w-24 h-24 text-red-500 fill-red-500 animate-ping opacity-90 drop-shadow-2xl" />
        </div>
      )}

      {/* Right Action Bar */}
      <div
        className="absolute right-3 bottom-20 z-20 flex flex-col items-center gap-4.5"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Author Avatar */}
        <div className="relative group cursor-pointer" onClick={() => onUserClick(video.userId)}>
          <div className="p-0.5 rounded-full ring-2 ring-cyan-400 shadow-lg">
            <Avatar
              src={video.user.avatarUrl}
              alt={video.user.displayName}
              size="sm"
            />
          </div>
        </div>

        {/* Like Button */}
        <button
          type="button"
          onClick={handleLike}
          className="flex flex-col items-center group focus:outline-none cursor-pointer"
          aria-label={isLiked ? 'Unlike' : 'Like'}
        >
          <div className="w-10 h-10 rounded-full bg-black/40 backdrop-blur-md flex items-center justify-center text-white group-hover:scale-110 active:scale-95 transition-transform">
            <Heart
              className={`w-5.5 h-5.5 transition-colors ${
                isLiked ? 'text-red-500 fill-red-500' : 'text-white stroke-[2.2px]'
              }`}
            />
          </div>
          <span className="text-[11px] font-bold text-white mt-1 drop-shadow-md">
            {likesCount}
          </span>
        </button>

        {/* Comments Button */}
        <button
          type="button"
          onClick={() => onCommentClick(video)}
          className="flex flex-col items-center group focus:outline-none cursor-pointer"
          aria-label="Comments"
        >
          <div className="w-10 h-10 rounded-full bg-black/40 backdrop-blur-md flex items-center justify-center text-white group-hover:scale-110 active:scale-95 transition-transform">
            <MessageCircle className="w-5.5 h-5.5 text-white stroke-[2.2px]" />
          </div>
          <span className="text-[11px] font-bold text-white mt-1 drop-shadow-md">
            {commentsCount}
          </span>
        </button>

        {/* Share Button */}
        <button
          type="button"
          onClick={handleShare}
          className="flex flex-col items-center group focus:outline-none cursor-pointer"
          aria-label="Share"
        >
          <div className="w-10 h-10 rounded-full bg-black/40 backdrop-blur-md flex items-center justify-center text-white group-hover:scale-110 active:scale-95 transition-transform">
            {copiedLink ? (
              <Check className="w-5 h-5 text-green-400" />
            ) : (
              <Share2 className="w-5.5 h-5.5 text-white stroke-[2.2px]" />
            )}
          </div>
          <span className="text-[11px] font-bold text-white mt-1 drop-shadow-md">
            {copiedLink ? 'Copied' : 'Share'}
          </span>
        </button>

        {/* Mute/Unmute Button */}
        <button
          type="button"
          onClick={onToggleMute}
          className="w-10 h-10 rounded-full bg-black/40 backdrop-blur-md flex items-center justify-center text-white hover:scale-110 active:scale-95 transition-transform cursor-pointer"
          aria-label={isMuted ? 'Unmute' : 'Mute'}
        >
          {isMuted ? (
            <VolumeX className="w-5 h-5 text-white/90" />
          ) : (
            <Volume2 className="w-5 h-5 text-cyan-400" />
          )}
        </button>
      </div>

      {/* Bottom Information Overlay */}
      <div
        className="absolute left-0 right-16 bottom-5 z-20 px-4 flex flex-col pointer-events-none"
      >
        <div className="pointer-events-auto">
          {/* Username */}
          <button
            type="button"
            onClick={() => onUserClick(video.userId)}
            className="text-sm font-extrabold text-white hover:text-cyan-400 transition-colors drop-shadow-md flex items-center gap-1.5 cursor-pointer text-left"
          >
            <span>@{video.user.username}</span>
            {video.user.isVerified && (
              <span className="w-3.5 h-3.5 bg-cyan-400 text-slate-950 rounded-full flex items-center justify-center text-[9px] font-black">
                ✓
              </span>
            )}
          </button>

          {/* Caption */}
          {video.caption && (
            <p className="text-xs text-slate-100 mt-1 line-clamp-3 leading-relaxed drop-shadow-md font-medium">
              {video.caption}
            </p>
          )}

          {/* Audio Track Indicator */}
          <div className="flex items-center gap-1.5 text-[11px] text-slate-300 mt-2 font-medium drop-shadow-md">
            <Music className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
            <span className="truncate">Original audio - {video.user.displayName}</span>
          </div>
        </div>
      </div>

      {/* Bottom Progress Bar */}
      <div className="absolute bottom-0 inset-x-0 h-1 bg-white/20 z-20 pointer-events-none">
        <div
          className="h-full bg-cyan-400 transition-all duration-100"
          style={{ width: `${progressPercent}%` }}
        />
      </div>
    </div>
  );
};
