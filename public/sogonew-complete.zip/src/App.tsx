import { useState } from 'react';
import { AuthProvider, useAuth } from './hooks/useAuth';
import { AppShell } from './layouts/AppShell';
import { ActiveTab, Post } from './types';
import { Home } from './pages/Home';
import { Discover } from './pages/Discover';
import { CreatePost } from './pages/CreatePost';
import { Videos } from './pages/Videos';
import { Bookmarks } from './pages/Bookmarks';
import { Notifications } from './pages/Notifications';
import { Profile } from './pages/Profile';
import { PostDetail } from './pages/PostDetail';
import { Settings } from './pages/Settings';
import { SettingsPrivacy } from './pages/SettingsPrivacy';
import { Login } from './pages/Login';
import { Splash } from './pages/Splash';
import { Onboarding } from './pages/Onboarding';
import sogoLogo from './assets/sogo-mark.svg';

function MainNavigator() {
  const { currentUser, loading, needsOnboarding, logout, completeOnboarding } = useAuth();
  const [currentTab, setCurrentTab] = useState<ActiveTab>('home');
  const [selectedPost, setSelectedPost] = useState<Post | null>(null);
  const [viewingUserId, setViewingUserId] = useState<string | null>(null);
  const [subView, setSubView] = useState<'none' | 'settings' | 'settings-privacy'>('none');

  // Prevent flashing the main app before authentication & Firestore status are established
  if (loading) {
    return (
      <div className="fixed inset-0 bg-[#0B0F1A] flex flex-col items-center justify-center text-white px-4">
        <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-purple-500/20 via-pink-500/20 to-cyan-500/20 border border-purple-500/30 flex items-center justify-center mb-4 shadow-xl shadow-purple-500/10 animate-pulse">
          <img src={sogoLogo} alt="Sogo" className="w-11 h-11 object-contain" />
        </div>
        <div className="w-5 h-5 border-2 border-cyan-400 border-t-transparent rounded-full animate-spin mb-3" />
        <p className="text-xs text-slate-400 font-medium tracking-wide">Connecting to Sogo...</p>
      </div>
    );
  }

  // If user is authenticated via Google but profile is incomplete/new, route to Onboarding screen
  if (currentUser && needsOnboarding) {
    return (
      <Onboarding
        user={currentUser}
        onComplete={async (profileData) => {
          await completeOnboarding(profileData);
        }}
        onCancel={async () => {
          await logout();
        }}
      />
    );
  }

  // Handle viewing another user's profile
  const handleUserClick = (userId: string) => {
    setViewingUserId(userId);
    setSelectedPost(null);
    setSubView('none');
    setCurrentTab('profile');
  };

  const handleTabChange = (tab: ActiveTab) => {
    setCurrentTab(tab);
    setSelectedPost(null);
    setSubView('none');
    if (tab === 'profile') {
      setViewingUserId(null); // Return to own profile
    }
  };

  const handlePostClick = (post: Post) => {
    setSelectedPost(post);
  };

  // Render Subviews or Active Tab
  const renderContent = () => {
    if (subView === 'settings-privacy') {
      return <SettingsPrivacy onBack={() => setSubView('settings')} />;
    }

    if (subView === 'settings') {
      return (
        <Settings
          onBack={() => setSubView('none')}
          onOpenPrivacy={() => setSubView('settings-privacy')}
          onLogout={async () => {
            await logout();
            setSubView('none');
            setCurrentTab('profile');
          }}
        />
      );
    }

    if (selectedPost) {
      return (
        <PostDetail
          post={selectedPost}
          onBack={() => setSelectedPost(null)}
          onUserClick={handleUserClick}
        />
      );
    }

    switch (currentTab) {
      case 'home':
        return (
          <Home
            onPostClick={handlePostClick}
            onUserClick={handleUserClick}
            onNavigateCreate={() => setCurrentTab('create')}
          />
        );
      case 'discover':
        return (
          <Discover
            onPostClick={handlePostClick}
            onUserClick={handleUserClick}
          />
        );
      case 'videos':
        return (
          <Videos
            onUserClick={handleUserClick}
            onNavigateCreate={() => setCurrentTab('create')}
          />
        );
      case 'create':
        if (!currentUser) {
          return (
            <div className="max-w-md mx-auto py-8 px-4">
              <Login onSuccess={() => setCurrentTab('create')} />
            </div>
          );
        }
        return (
          <CreatePost
            onCreated={(type) => {
              if (type === 'video') {
                setCurrentTab('videos');
              } else {
                setCurrentTab('home');
              }
            }}
            onCancel={() => setCurrentTab('home')}
          />
        );
      case 'bookmarks':
        return (
          <Bookmarks
            onPostClick={handlePostClick}
            onExploreClick={() => setCurrentTab('discover')}
          />
        );
      case 'notifications':
        return <Notifications onUserClick={handleUserClick} />;
      case 'profile':
        return (
          <Profile
            userId={viewingUserId || currentUser?.id}
            onPostClick={handlePostClick}
            onSettingsClick={() => setSubView('settings')}
            onNavigateVideos={() => setCurrentTab('videos')}
          />
        );
      default:
        return (
          <Home
            onPostClick={handlePostClick}
            onUserClick={handleUserClick}
            onNavigateCreate={() => setCurrentTab('create')}
          />
        );
    }
  };

  return (
    <AppShell
      currentTab={currentTab}
      onTabChange={handleTabChange}
      unreadNotificationsCount={2}
    >
      {renderContent()}
    </AppShell>
  );
}

export default function App() {
  const [showSplash, setShowSplash] = useState(false);

  if (showSplash) {
    return <Splash onFinish={() => setShowSplash(false)} />;
  }

  return (
    <AuthProvider>
      <MainNavigator />
    </AuthProvider>
  );
}
