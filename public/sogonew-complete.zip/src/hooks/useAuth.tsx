import React, { createContext, useContext, useState, useEffect } from 'react';
import { User } from '../types';
import * as authService from '../services/authService';

interface AuthContextType {
  currentUser: User | null;
  loading: boolean;
  needsOnboarding: boolean;
  loginWithGoogle: () => Promise<User>;
  logout: () => Promise<void>;
  updateProfile: (data: Partial<User>) => void;
  completeOnboarding: (profileData: {
    displayName: string;
    username: string;
    birthday: string;
    avatarUrl: string;
    bio?: string;
    website?: string;
  }) => Promise<User>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    try {
      const cached = localStorage.getItem('sogo_auth_user');
      if (cached) {
        setCurrentUser(JSON.parse(cached));
      }
    } catch {}

    // Initialize Capacitor SocialLogin plugin once on startup
    authService.initializeSocialLogin();

    const unsubscribe = authService.subscribeToAuthState((user, isVerified) => {
      if (user && isVerified !== false) {
        setCurrentUser(user);
      } else {
        setCurrentUser(null);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const loginWithGoogle = async (): Promise<User> => {
    setLoading(true);
    try {
      const user = await authService.loginWithGoogle();
      setCurrentUser(user);
      return user;
    } finally {
      setLoading(false);
    }
  };

  const logout = async () => {
    await authService.logout();
    setCurrentUser(null);
  };

  const updateProfile = (data: Partial<User>) => {
    if (currentUser) {
      const updated = { ...currentUser, ...data };
      setCurrentUser(updated);
      authService.saveCurrentUser(updated);
    }
  };

  const completeOnboarding = async (profileData: {
    displayName: string;
    username: string;
    birthday: string;
    avatarUrl: string;
    bio?: string;
    website?: string;
  }): Promise<User> => {
    if (!currentUser?.id) {
      throw new Error('No authenticated user session found.');
    }
    const updated = await authService.completeUserProfile(currentUser.id, profileData);
    setCurrentUser(updated);
    return updated;
  };

  const needsOnboarding = Boolean(
    currentUser &&
    currentUser.id &&
    !currentUser.id.startsWith('user_') &&
    currentUser.isOnboarded !== true &&
    !currentUser.birthday
  );

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        loading,
        needsOnboarding,
        loginWithGoogle,
        logout,
        updateProfile,
        completeOnboarding,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}

