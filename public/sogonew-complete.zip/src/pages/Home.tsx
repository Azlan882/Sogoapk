import React, { useState, useEffect } from 'react';
import { Post, Story } from '../types';
import { PostCard } from '../components/PostCard';
import { StoryItem } from '../components/StoryItem';
import { EmptyState } from '../components/EmptyState';
import { LoadingState } from '../components/LoadingState';
import { useAuth } from '../hooks/useAuth';
import * as postsService from '../services/postsService';
import * as storiesService from '../services/storiesService';
import { Plus, X, Sparkles, RefreshCw } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export interface HomeProps {
  onPostClick: (post: Post) => void;
  onUserClick: (userId: string) => void;
  onNavigateCreate: () => void;
}

export const Home: React.FC<HomeProps> = ({ onPostClick, onUserClick, onNavigateCreate }) => {
  const { currentUser } = useAuth();
  const [posts, setPosts] = useState<Post[]>([]);
  const [stories, setStories] = useState<Story[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeStory, setActiveStory] = useState<Story | null>(null);
  const [storyProgress, setStoryProgress] = useState(0);

  const loadData = async () => {
    setLoading(true);
    try {
      const [feedPosts, activeStories] = await Promise.all([
        postsService.getFeedPosts(),
        storiesService.getActiveStories(),
      ]);
      setPosts(feedPosts);
      setStories(activeStories);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  // Story Viewer Timer Progress
  useEffect(() => {
    if (!activeStory) return;
    setStoryProgress(0);
    const interval = setInterval(() => {
      setStoryProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setActiveStory(null);
          return 0;
        }
        return prev + 2;
      });
    }, 100);

    return () => clearInterval(interval);
  }, [activeStory]);

  const handleLike = async (postId: string) => {
    const updated = await postsService.toggleLikePost(postId);
    setPosts((prev) =>
      prev.map((p) =>
        p.id === postId ? { ...p, isLiked: updated.isLiked, likesCount: updated.likesCount } : p
      )
    );
  };

  const handleBookmark = async (postId: string) => {
    const isBookmarked = await postsService.toggleBookmarkPost(postId);
    setPosts((prev) =>
      prev.map((p) => (p.id === postId ? { ...p, isBookmarked } : p))
    );
  };

  const handleQuickComment = async (postId: string, text: string) => {
    if (!currentUser) return;
    await postsService.addComment(
      postId,
      {
        id: currentUser.id,
        username: currentUser.username,
        displayName: currentUser.displayName,
        avatarUrl: currentUser.avatarUrl,
      },
      text
    );
    setPosts((prev) =>
      prev.map((p) => (p.id === postId ? { ...p, commentsCount: p.commentsCount + 1 } : p))
    );
  };

  const handleStoryClick = (story: Story) => {
    setActiveStory(story);
    storiesService.markStorySeen(story.id);
    setStories((prev) =>
      prev.map((s) => (s.id === story.id ? { ...s, hasSeen: true } : s))
    );
  };

  const handleShare = (post: Post) => {
    if (navigator.share) {
      navigator.share({
        title: `Post by ${post.user.displayName} on Sogo`,
        text: post.caption,
        url: window.location.href,
      }).catch(() => {});
    } else {
      navigator.clipboard.writeText(window.location.href);
      alert('Post link copied to clipboard!');
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Stories Reel */}
      <section className="bg-slate-900 rounded-2xl border border-slate-800 p-3.5 sm:p-4 shadow-sm">
        <div className="flex items-center gap-4 overflow-x-auto no-scrollbar py-1">
          {/* Add Story Button for Current User */}
          <div className="flex flex-col items-center gap-1.5 shrink-0">
            <button
              type="button"
              onClick={onNavigateCreate}
              className="relative w-14 h-14 rounded-full bg-slate-800 border-2 border-dashed border-slate-700 hover:border-cyan-400 flex items-center justify-center text-slate-400 hover:text-cyan-400 transition-colors focus:outline-none group cursor-pointer"
            >
              <Plus className="w-6 h-6 group-hover:scale-110 transition-transform" />
            </button>
            <span className="text-xs font-medium text-slate-300">Your Story</span>
          </div>

          {/* Stories List */}
          {stories.map((story) => (
            <StoryItem
              key={story.id}
              story={story}
              onClick={handleStoryClick}
            />
          ))}
        </div>
      </section>

      {/* Feed Stream */}
      {loading ? (
        <LoadingState message="Fetching your Sogo feed..." />
      ) : posts.length === 0 ? (
        <EmptyState
          icon={<Sparkles className="w-6 h-6 text-cyan-400" />}
          title="No Posts in Feed"
          description="Be the very first creator to share a photo or thought with the community!"
          actionText="Create a Post"
          onAction={onNavigateCreate}
        />
      ) : (
        <section className="space-y-6">
          <div className="flex items-center justify-between px-1">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Latest Stories & Posts
            </span>
            <button
              type="button"
              onClick={loadData}
              className="flex items-center gap-1 text-xs text-slate-400 hover:text-cyan-400 transition-colors"
            >
              <RefreshCw className="w-3 h-3" />
              <span>Refresh</span>
            </button>
          </div>

          {posts.map((post) => (
            <PostCard
              key={post.id}
              post={post}
              onLike={handleLike}
              onBookmark={handleBookmark}
              onCommentClick={onPostClick}
              onUserClick={onUserClick}
              onShare={handleShare}
              onQuickComment={handleQuickComment}
            />
          ))}
        </section>
      )}

      {/* Full-screen Active Story Viewer Modal */}
      <AnimatePresence>
        {activeStory && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/95 flex items-center justify-center p-4 backdrop-blur-sm"
          >
            <div className="relative w-full max-w-sm aspect-9/16 bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-2xl flex flex-col justify-between">
              {/* Progress Bar */}
              <div className="absolute top-3 inset-x-3 z-20 flex gap-1">
                <div className="h-1 bg-white/30 rounded-full flex-1 overflow-hidden">
                  <div
                    className="h-full bg-cyan-400 transition-all duration-100 ease-linear"
                    style={{ width: `${storyProgress}%` }}
                  />
                </div>
              </div>

              {/* Story Header */}
              <div className="relative z-20 p-4 pt-6 flex items-center justify-between text-white bg-gradient-to-b from-black/70 to-transparent">
                <div className="flex items-center gap-2.5">
                  <img
                    src={activeStory.user.avatarUrl}
                    alt={activeStory.user.displayName}
                    className="w-8 h-8 rounded-full border border-cyan-400/60 object-cover"
                  />
                  <span className="text-xs font-bold">{activeStory.user.username}</span>
                </div>
                <button
                  type="button"
                  onClick={() => setActiveStory(null)}
                  className="p-1.5 rounded-full bg-slate-800/80 hover:bg-slate-700 text-white focus:outline-none"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Story Media */}
              <img
                src={activeStory.mediaUrl}
                alt="Story content"
                className="absolute inset-0 w-full h-full object-cover"
              />

              {/* Story Bottom Reply */}
              <div className="relative z-20 p-4 bg-gradient-to-t from-black/90 to-transparent flex items-center gap-2">
                <input
                  type="text"
                  placeholder="Send reply..."
                  className="flex-1 px-4 py-2 bg-slate-900/60 backdrop-blur-md rounded-xl text-xs text-white placeholder:text-slate-400 focus:outline-none border border-slate-700"
                />
                <button
                  type="button"
                  onClick={() => {
                    setActiveStory(null);
                  }}
                  className="px-3.5 py-2 bg-cyan-500 hover:bg-cyan-400 text-slate-900 text-xs font-bold rounded-xl shadow-md shadow-cyan-500/20"
                >
                  Send
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
