import React, { useState } from 'react';
import { useAuth } from '../hooks/useAuth';
import { Button } from '../components/Button';
import {
  Shield,
  Bell,
  Eye,
  LogOut,
  ChevronRight,
  ArrowLeft,
  Moon,
  HelpCircle,
  Sparkles,
  Smartphone,
  Download,
  Github,
  CheckCircle2,
  X,
} from 'lucide-react';

export interface SettingsProps {
  onBack: () => void;
  onOpenPrivacy: () => void;
  onLogout: () => void;
}

export const Settings: React.FC<SettingsProps> = ({ onBack, onOpenPrivacy, onLogout }) => {
  const { currentUser } = useAuth();
  const [showApkModal, setShowApkModal] = useState(false);

  return (
    <div className="bg-slate-900 rounded-3xl border border-slate-800 p-5 sm:p-8 shadow-sm space-y-6">
      {/* Header */}
      <div className="flex items-center gap-3 pb-4 border-b border-slate-800">
        <button
          type="button"
          onClick={onBack}
          className="p-2 text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-full transition-colors focus:outline-none"
        >
          <ArrowLeft className="w-4 h-4" />
        </button>
        <h1 className="text-xl font-bold text-white">Settings</h1>
      </div>

      {/* Account Info Card */}
      {currentUser && (
        <div className="p-4 bg-slate-800/60 rounded-2xl border border-slate-700/80 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img
              src={currentUser.avatarUrl}
              alt={currentUser.displayName}
              className="w-12 h-12 rounded-full object-cover border border-cyan-400/40"
            />
            <div>
              <p className="font-bold text-sm text-white">{currentUser.displayName}</p>
              <p className="text-xs text-slate-400">{currentUser.email || `@${currentUser.username}`}</p>
            </div>
          </div>
          <span className="text-[11px] font-semibold bg-cyan-950/60 text-cyan-400 border border-cyan-800/40 px-2.5 py-1 rounded-full">
            Active
          </span>
        </div>
      )}

      {/* Preferences Section */}
      <div className="space-y-1">
        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2 px-1">
          Preferences & Security
        </h3>

        <button
          type="button"
          onClick={onOpenPrivacy}
          className="w-full flex items-center justify-between p-3.5 hover:bg-slate-800/80 rounded-xl transition-colors text-left"
        >
          <div className="flex items-center gap-3">
            <Shield className="w-5 h-5 text-slate-400" />
            <div>
              <p className="text-sm font-semibold text-slate-200">Privacy & Security</p>
              <p className="text-xs text-slate-400">Account visibility, blocked users, permissions</p>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-500" />
        </button>

        <div className="w-full flex items-center justify-between p-3.5 hover:bg-slate-800/80 rounded-xl transition-colors">
          <div className="flex items-center gap-3">
            <Bell className="w-5 h-5 text-slate-400" />
            <div>
              <p className="text-sm font-semibold text-slate-200">Push Notifications</p>
              <p className="text-xs text-slate-400">Likes, comments, and story mentions</p>
            </div>
          </div>
          <input
            type="checkbox"
            defaultChecked
            className="w-4 h-4 accent-cyan-400 rounded cursor-pointer"
          />
        </div>

        <div className="w-full flex items-center justify-between p-3.5 hover:bg-slate-800/80 rounded-xl transition-colors">
          <div className="flex items-center gap-3">
            <Eye className="w-5 h-5 text-slate-400" />
            <div>
              <p className="text-sm font-semibold text-slate-200">Activity Status</p>
              <p className="text-xs text-slate-400">Show when you are active on Sogo</p>
            </div>
          </div>
          <input
            type="checkbox"
            defaultChecked
            className="w-4 h-4 accent-cyan-400 rounded cursor-pointer"
          />
        </div>

        <div className="w-full flex items-center justify-between p-3.5 hover:bg-slate-800/80 rounded-xl transition-colors">
          <div className="flex items-center gap-3">
            <Moon className="w-5 h-5 text-slate-400" />
            <div>
              <p className="text-sm font-semibold text-slate-200">Theme Mode</p>
              <p className="text-xs text-slate-400">Sleek Interface (Dark)</p>
            </div>
          </div>
          <span className="text-xs font-semibold text-cyan-400 bg-slate-800 border border-slate-700 px-2 py-1 rounded-md">
            Sleek Dark
          </span>
        </div>
      </div>

      {/* Android APK & GitHub Build */}
      <div className="space-y-2 pt-2 border-t border-slate-800">
        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2 px-1">
          Android APK & Build
        </h3>

        <button
          type="button"
          onClick={() => setShowApkModal(true)}
          className="w-full flex items-center justify-between p-3.5 bg-gradient-to-r from-cyan-950/40 to-blue-950/40 hover:from-cyan-900/50 hover:to-blue-900/50 border border-cyan-800/50 rounded-xl transition-all text-left group"
        >
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-cyan-500/20 text-cyan-400 border border-cyan-500/30">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <p className="text-sm font-bold text-white">Get APK File via GitHub</p>
                <span className="text-[10px] font-extrabold uppercase px-1.5 py-0.5 rounded bg-cyan-500 text-slate-950">
                  Ready
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">Automated GitHub Actions workflow & Capacitor build</p>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-cyan-400 group-hover:translate-x-0.5 transition-transform" />
        </button>
      </div>

      {/* Support & About */}
      <div className="space-y-1 pt-2 border-t border-slate-800">
        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2 px-1">
          About
        </h3>

        <div className="flex items-center justify-between p-3.5 text-slate-300">
          <div className="flex items-center gap-3">
            <HelpCircle className="w-5 h-5 text-slate-400" />
            <span className="text-sm font-medium">Sogo Platform Version</span>
          </div>
          <span className="text-xs font-semibold text-slate-500">v1.2.0 (React 19)</span>
        </div>

        <div className="flex items-center justify-between p-3.5 text-slate-300">
          <div className="flex items-center gap-3">
            <Sparkles className="w-5 h-5 text-cyan-400" />
            <span className="text-sm font-medium">Built with Google AI Studio</span>
          </div>
          <span className="text-xs font-semibold text-slate-500">Asia-SE1</span>
        </div>
      </div>

      {/* Logout */}
      <div className="pt-4 border-t border-slate-800">
        <Button
          variant="outline"
          size="md"
          leftIcon={<LogOut className="w-4 h-4 text-rose-400" />}
          onClick={onLogout}
          className="w-full text-rose-400 hover:bg-rose-950/30 border-rose-900/60"
        >
          Sign Out of Sogo
        </Button>
      </div>

      {/* APK & GitHub Build Instructions Modal */}
      {showApkModal && (
        <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4 backdrop-blur-xs">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 max-w-lg w-full shadow-2xl space-y-5 text-slate-200 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-cyan-500/20 text-cyan-400 border border-cyan-500/30">
                  <Smartphone className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="font-bold text-base text-white">Download APK via GitHub</h2>
                  <p className="text-xs text-slate-400">Capacitor Android + GitHub Actions Workflow</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowApkModal(false)}
                className="p-1 rounded-full text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4 text-sm">
              <div className="p-3.5 bg-cyan-950/40 border border-cyan-800/60 rounded-2xl text-xs text-cyan-200 flex items-start gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                <div>
                  <p className="font-bold text-cyan-300">Repository is Pre-configured!</p>
                  <p className="text-cyan-200/90 mt-0.5 leading-relaxed">
                    The native Android project and GitHub Actions workflow (<code className="bg-slate-950 px-1 py-0.5 rounded text-cyan-300">.github/workflows/build-apk.yml</code>) are already in your project code.
                  </p>
                </div>
              </div>

              {/* Step 1 */}
              <div className="space-y-1.5 bg-slate-800/50 p-3.5 rounded-2xl border border-slate-700/60">
                <div className="flex items-center gap-2">
                  <span className="w-6 h-6 rounded-full bg-cyan-500 text-slate-950 font-black text-xs flex items-center justify-center">1</span>
                  <p className="font-bold text-white text-xs sm:text-sm">Export this Project to GitHub</p>
                </div>
                <p className="text-xs text-slate-400 pl-8 leading-relaxed">
                  In Google AI Studio, open the top-right menu and select <strong>Export to GitHub</strong> (or download the ZIP and push it to your GitHub repository).
                </p>
              </div>

              {/* Step 2 */}
              <div className="space-y-1.5 bg-slate-800/50 p-3.5 rounded-2xl border border-slate-700/60">
                <div className="flex items-center gap-2">
                  <span className="w-6 h-6 rounded-full bg-cyan-500 text-slate-950 font-black text-xs flex items-center justify-center">2</span>
                  <p className="font-bold text-white text-xs sm:text-sm">Pre-Configured Firebase Client</p>
                </div>
                <p className="text-xs text-slate-400 pl-8 leading-relaxed">
                  Your Firebase client configuration (Project: <strong>sogo-e5ea9</strong>) is directly embedded. No environment variable or secret setup is required for GitHub Actions to build.
                </p>
              </div>

              {/* Step 3 */}
              <div className="space-y-1.5 bg-slate-800/50 p-3.5 rounded-2xl border border-slate-700/60">
                <div className="flex items-center gap-2">
                  <span className="w-6 h-6 rounded-full bg-cyan-500 text-slate-950 font-black text-xs flex items-center justify-center">3</span>
                  <p className="font-bold text-white text-xs sm:text-sm">GitHub Builds the APK Automatically</p>
                </div>
                <p className="text-xs text-slate-400 pl-8 leading-relaxed">
                  On your GitHub repository, click the <strong>"Actions"</strong> tab. The <strong>"Build Android APK"</strong> workflow will run automatically and compile the native Android APK.
                </p>
              </div>

              {/* Step 4 */}
              <div className="space-y-1.5 bg-slate-800/50 p-3.5 rounded-2xl border border-slate-700/60">
                <div className="flex items-center gap-2">
                  <span className="w-6 h-6 rounded-full bg-cyan-500 text-slate-950 font-black text-xs flex items-center justify-center">4</span>
                  <p className="font-bold text-white text-xs sm:text-sm">Download your .apk File</p>
                </div>
                <p className="text-xs text-slate-400 pl-8 leading-relaxed">
                  Click on the completed workflow run, scroll down to <strong>Artifacts</strong>, and click <strong>sogo-android-debug-apk</strong> to download your ready-to-install Android APK!
                </p>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
              <Button variant="primary" size="sm" onClick={() => setShowApkModal(false)}>
                Got it
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
