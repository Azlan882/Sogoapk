import React, { useState, useEffect, useRef, useCallback } from 'react';
import { DocumentSnapshot } from 'firebase/firestore';
import { Plus, RefreshCw, Film } from 'lucide-react';
import { VideoPost } from '../types';
import * as videosService from '../services/videosService';
import { VideoItem } from '../components/VideoItem';
import { VideoCommentsDrawer } from '../components/VideoCommentsDrawer';
import { useAuth } from '../hooks/useAuth';

export interface VideosProps {
  onUserClick: (userId: string) => void;
  onNavigateCreate: () => void;
}

export const Videos: React.FC<VideosProps> = ({ onUserClick, onNavigateCreate }) => {
  const { currentUser } = useAuth();
  const [videos, setVideos] = useState<VideoPost[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [loadingMore, setLoadingMore] = useState(false);
  const [lastCursor, setLastCursor] = useState<DocumentSnapshot | null>(null);
  const [hasMore, setHasMore] = useState(true);

  const [activeIndex, setActiveIndex] = useState(0);
  const [isMuted, setIsMuted] = useState(false);

  // Comments drawer state
  const [selectedVideoForComments, setSelectedVideoForComments] = useState<VideoPost | null>(null);

  const containerRef = useRef<HTMLDivElement | null>(null);
  const videoRefs = useRef<(HTMLDivElement | null)[]>([]);

  // Load initial videos
  const fetchInitialVideos = useCallback(async () => {
    setLoading(true);
    try {
      const res = await videosService.getVideos(null, 6, currentUser?.id);
      setVideos(res.videos);
      setLastCursor(res.nextCursor);
      setHasMore(!!res.nextCursor);
    } catch (err) {
      console.error('Failed to load initial videos', err);
    } finally {
      setLoading(false);
    }
  }, [currentUser?.id]);

  useEffect(() => {
    fetchInitialVideos();
  }, [fetchInitialVideos]);

  // Pull / button to refresh
  const handleRefresh = async () => {
    setRefreshing(true);
    try {
      const res = await videosService.getVideos(null, 6, currentUser?.id);
      setVideos(res.videos);
      setLastCursor(res.nextCursor);
      setHasMore(!!res.nextCursor);
      setActiveIndex(0);
      if (containerRef.current) {
        containerRef.current.scrollTo({ top: 0, behavior: 'smooth' });
      }
    } catch (err) {
      console.error('Failed to refresh videos', err);
    } finally {
      setRefreshing(false);
    }
  };

  // Load more videos when near the end
  const loadMoreVideos = async () => {
    if (loadingMore || !hasMore || !lastCursor) return;
    setLoadingMore(true);
    try {
      const res = await videosService.getVideos(lastCursor, 6, currentUser?.id);
      if (res.videos.length > 0) {
        setVideos((prev) => [...prev, ...res.videos]);
        setLastCursor(res.nextCursor);
        setHasMore(!!res.nextCursor);
      } else {
        setHasMore(false);
      }
    } catch (err) {
      console.error('Failed to load more videos', err);
    } finally {
      setLoadingMore(false);
    }
  };

  // IntersectionObserver to accurately detect which video is currently active in viewport
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting && entry.intersectionRatio >= 0.5) {
            const index = Number(entry.target.getAttribute('data-index'));
            if (!isNaN(index)) {
              setActiveIndex(index);
              // If within 2 videos of the end, prefetch more
              if (index >= videos.length - 2 && hasMore && !loadingMore) {
                loadMoreVideos();
              }
            }
          }
        });
      },
      {
        root: container,
        threshold: 0.5,
      }
    );

    videoRefs.current.forEach((el) => {
      if (el) observer.observe(el);
    });

    return () => {
      observer.disconnect();
    };
  }, [videos, hasMore, loadingMore]);

  const handleVideoUpdated = (updatedVideo: VideoPost) => {
    setVideos((prev) =>
      prev.map((v) => (v.id === updatedVideo.id ? updatedVideo : v))
    );
  };

  return (
    <div className="relative w-full h-[calc(100vh-4rem)] sm:h-[calc(100vh-4.5rem)] bg-black overflow-hidden flex flex-col">
      {/* Top Floating Header with Sogo branding & Quick Create button */}
      <div className="absolute top-0 inset-x-0 z-30 flex items-center justify-between px-4 py-3 bg-gradient-to-b from-black/80 via-black/40 to-transparent pointer-events-none">
        <div className="flex items-center gap-2 pointer-events-auto">
          <Film className="w-5 h-5 text-cyan-400" />
          <h1 className="text-base font-extrabold text-white tracking-wide drop-shadow-md">
            Reels
          </h1>
        </div>

        <div className="flex items-center gap-2 pointer-events-auto">
          <button
            type="button"
            onClick={handleRefresh}
            disabled={refreshing}
            className="p-2 rounded-full bg-black/40 text-slate-300 hover:text-white backdrop-blur-md transition-colors cursor-pointer"
            aria-label="Refresh feed"
          >
            <RefreshCw className={`w-4 h-4 ${refreshing ? 'animate-spin text-cyan-400' : ''}`} />
          </button>

          <button
            type="button"
            onClick={onNavigateCreate}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-gradient-to-r from-cyan-500 to-blue-600 hover:brightness-110 text-white font-bold text-xs rounded-full shadow-lg shadow-cyan-500/25 transition-transform active:scale-95 cursor-pointer"
          >
            <Plus className="w-4 h-4 stroke-[2.5px]" />
            <span>Create</span>
          </button>
        </div>
      </div>

      {/* Main Feed Container */}
      {loading ? (
        <div className="flex-1 flex flex-col items-center justify-center text-slate-400">
          <div className="w-10 h-10 border-3 border-cyan-400 border-t-transparent rounded-full animate-spin mb-3" />
          <p className="text-xs font-semibold text-slate-300">Loading videos...</p>
        </div>
      ) : videos.length === 0 ? (
        <div className="flex-1 flex flex-col items-center justify-center text-center px-6 bg-[#0B0F1A]">
          <div className="w-16 h-16 rounded-3xl bg-gradient-to-br from-cyan-500/10 to-blue-600/10 border border-cyan-500/20 flex items-center justify-center text-cyan-400 mb-4 shadow-xl">
            <Film className="w-8 h-8" />
          </div>
          <h2 className="text-lg font-extrabold text-white">No videos yet</h2>
          <p className="text-xs text-slate-400 mt-1 max-w-xs leading-relaxed">
            Be the very first to share a short video clip with the Sogo community!
          </p>
          <button
            type="button"
            onClick={onNavigateCreate}
            className="mt-6 flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-cyan-400 to-blue-600 text-slate-950 font-bold text-xs rounded-2xl shadow-lg shadow-cyan-500/25 hover:brightness-110 transition-transform active:scale-95 cursor-pointer"
          >
            <Plus className="w-4 h-4 stroke-[3px]" />
            <span>Post First Video</span>
          </button>
        </div>
      ) : (
        <div
          ref={containerRef}
          className="flex-1 w-full h-full overflow-y-scroll snap-y snap-mandatory scroll-smooth no-scrollbar"
        >
          {videos.map((video, index) => {
            // Keep memory footprint lean: only mount full video for current, previous, and next
            const shouldRender = Math.abs(activeIndex - index) <= 2;

            return (
              <div
                key={video.id}
                ref={(el) => {
                  videoRefs.current[index] = el;
                }}
                data-index={index}
                className="w-full h-full snap-start snap-always"
              >
                {shouldRender ? (
                  <VideoItem
                    video={video}
                    isActive={activeIndex === index}
                    isMuted={isMuted}
                    onToggleMute={() => setIsMuted((prev) => !prev)}
                    onUserClick={onUserClick}
                    onCommentClick={(v) => setSelectedVideoForComments(v)}
                    onVideoUpdated={handleVideoUpdated}
                  />
                ) : (
                  <div className="w-full h-full bg-black flex items-center justify-center">
                    {video.thumbnailUrl && (
                      <img
                        src={video.thumbnailUrl}
                        alt="Video poster"
                        className="w-full h-full object-cover opacity-30"
                      />
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Slide-up Comments Drawer */}
      {selectedVideoForComments && (
        <VideoCommentsDrawer
          video={selectedVideoForComments}
          isOpen={!!selectedVideoForComments}
          onClose={() => setSelectedVideoForComments(null)}
          onCommentAdded={() => {
            // Increment comment count locally on the video
            setVideos((prev) =>
              prev.map((v) =>
                v.id === selectedVideoForComments.id
                  ? { ...v, commentsCount: v.commentsCount + 1 }
                  : v
              )
            );
          }}
        />
      )}
    </div>
  );
};
