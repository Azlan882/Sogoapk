import React, { useState } from 'react';
import { NotificationItem } from '../types';
import { Avatar } from '../components/Avatar';
import { timeAgo } from '../lib/utils';
import { Heart, MessageCircle, UserPlus, Sparkles, Check } from 'lucide-react';

export interface NotificationsProps {
  onUserClick?: (userId: string) => void;
}

const INITIAL_NOTIFICATIONS: NotificationItem[] = [
  {
    id: 'notif_1',
    type: 'like',
    fromUser: {
      id: 'user_2',
      username: 'maya_lens',
      displayName: 'Maya Chen',
      avatarUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=300&auto=format&fit=crop&q=80',
    },
    postId: 'post_2',
    postImageUrl: 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?w=1200&auto=format&fit=crop&q=80',
    createdAt: new Date(Date.now() - 40 * 60000).toISOString(),
    read: false,
  },
  {
    id: 'notif_2',
    type: 'comment',
    fromUser: {
      id: 'user_3',
      username: 'alex_design',
      displayName: 'Alex Rivers',
      avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&auto=format&fit=crop&q=80',
    },
    text: 'Blade Runner vibes. Absolutely stunning composition.',
    postId: 'post_1',
    postImageUrl: 'https://images.unsplash.com/photo-1514565131-fce0801e5785?w=1200&auto=format&fit=crop&q=80',
    createdAt: new Date(Date.now() - 3 * 3600000).toISOString(),
    read: false,
  },
  {
    id: 'notif_3',
    type: 'follow',
    fromUser: {
      id: 'user_4',
      username: 'sophia_travel',
      displayName: 'Sophia Laurent',
      avatarUrl: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=300&auto=format&fit=crop&q=80',
    },
    createdAt: new Date(Date.now() - 24 * 3600000).toISOString(),
    read: true,
  },
];

export const Notifications: React.FC<NotificationsProps> = ({ onUserClick }) => {
  const [notifications, setNotifications] = useState<NotificationItem[]>(INITIAL_NOTIFICATIONS);

  const markAllAsRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
  };

  const getIcon = (type: NotificationItem['type']) => {
    switch (type) {
      case 'like':
        return <Heart className="w-3.5 h-3.5 text-rose-500 fill-rose-500" />;
      case 'comment':
        return <MessageCircle className="w-3.5 h-3.5 text-cyan-400 fill-cyan-400/20" />;
      case 'follow':
        return <UserPlus className="w-3.5 h-3.5 text-blue-400" />;
      default:
        return <Sparkles className="w-3.5 h-3.5 text-amber-400" />;
    }
  };

  const getMessage = (notif: NotificationItem) => {
    switch (notif.type) {
      case 'like':
        return 'liked your visual publication';
      case 'comment':
        return `commented: "${notif.text}"`;
      case 'follow':
        return 'started following your creative journey';
      default:
        return 'interacted with your profile';
    }
  };

  return (
    <div className="bg-slate-900 rounded-2xl border border-slate-800 p-4 sm:p-6 shadow-sm space-y-4">
      <div className="flex items-center justify-between pb-3 border-b border-slate-800">
        <h1 className="text-lg font-bold text-white">Activity & Alerts</h1>
        <button
          type="button"
          onClick={markAllAsRead}
          className="text-xs font-semibold text-cyan-400 hover:text-cyan-300 flex items-center gap-1 focus:outline-none"
        >
          <Check className="w-3.5 h-3.5" />
          Mark all as read
        </button>
      </div>

      <div className="divide-y divide-slate-800/80">
        {notifications.map((notif) => (
          <div
            key={notif.id}
            className={`flex items-center justify-between py-3.5 gap-3 transition-colors ${
              !notif.read ? 'bg-cyan-950/30 -mx-2 px-2 rounded-xl' : ''
            }`}
          >
            <div className="flex items-center gap-3 min-w-0">
              <div className="relative">
                <Avatar
                  src={notif.fromUser.avatarUrl}
                  alt={notif.fromUser.displayName}
                  size="md"
                  onClick={() => onUserClick?.(notif.fromUser.id)}
                />
                <div className="absolute -bottom-1 -right-1 p-1 bg-slate-900 rounded-full border border-slate-700 shadow-xs">
                  {getIcon(notif.type)}
                </div>
              </div>

              <div className="min-w-0 text-sm">
                <p className="text-slate-300 leading-snug">
                  <button
                    type="button"
                    onClick={() => onUserClick?.(notif.fromUser.id)}
                    className="font-bold text-white hover:underline mr-1 focus:outline-none"
                  >
                    {notif.fromUser.displayName}
                  </button>
                  <span className="text-slate-400">{getMessage(notif)}</span>
                </p>
                <span className="text-xs text-slate-500 mt-0.5 block">
                  {timeAgo(notif.createdAt)}
                </span>
              </div>
            </div>

            {notif.postImageUrl && (
              <img
                src={notif.postImageUrl}
                alt="Post reference"
                className="w-11 h-11 rounded-lg object-cover shrink-0 border border-slate-800"
              />
            )}
          </div>
        ))}
      </div>
    </div>
  );
};
