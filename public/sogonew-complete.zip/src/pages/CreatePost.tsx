import React, { useState, useRef } from 'react';
import { useAuth } from '../hooks/useAuth';
import { Button } from '../components/Button';
import * as postsService from '../services/postsService';
import * as storiesService from '../services/storiesService';
import * as storageService from '../services/storageService';
import * as videosService from '../services/videosService';
import { UploadCloud, MapPin, Hash, Check, Sparkles, Film, Video } from 'lucide-react';

export interface CreatePostProps {
  onCreated: (type?: 'feed' | 'story' | 'video') => void;
  onCancel?: () => void;
}

const PRESET_PHOTOS = [
  'https://images.unsplash.com/photo-1506744038136-46273834b3fb?w=1200&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1518791841217-8f162f1e1131?w=1200&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?w=1200&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=1200&auto=format&fit=crop&q=80',
];

export const CreatePost: React.FC<CreatePostProps> = ({ onCreated, onCancel }) => {
  const { currentUser } = useAuth();
  const [postType, setPostType] = useState<'feed' | 'story' | 'video'>('feed');
  const [imageUrl, setImageUrl] = useState('');
  const [caption, setCaption] = useState('');
  const [tagsInput, setTagsInput] = useState('');
  const [location, setLocation] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  // Video-specific states
  const [videoFile, setVideoFile] = useState<File | null>(null);
  const [videoPreviewUrl, setVideoPreviewUrl] = useState<string>('');
  const [uploadProgress, setUploadProgress] = useState<number>(0);
  const [uploadPhase, setUploadPhase] = useState<'idle' | 'uploading' | 'processing'>('idle');

  const videoInputRef = useRef<HTMLInputElement | null>(null);
  const imageInputRef = useRef<HTMLInputElement | null>(null);

  // Existing image file handler
  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      setLoading(true);
      setError('');
      const dataUrl = await storageService.uploadImage(file);
      setImageUrl(dataUrl);
    } catch (err) {
      setError('Failed to load image file');
    } finally {
      setLoading(false);
    }
  };

  // Video file picker handler
  const handleVideoSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Check video format
    if (!file.type.startsWith('video/')) {
      setError('Please select a valid video file (MP4, WebM, MOV)');
      return;
    }

    // Check size limit: 100MB max
    if (file.size > 100 * 1024 * 1024) {
      setError('Video is too large. Maximum supported size is 100MB.');
      return;
    }

    setError('');
    setVideoFile(file);

    // Create local object URL for instant preview
    const preview = URL.createObjectURL(file);
    setVideoPreviewUrl(preview);
  };

  const handleClearVideo = () => {
    if (videoPreviewUrl) {
      URL.revokeObjectURL(videoPreviewUrl);
    }
    setVideoFile(null);
    setVideoPreviewUrl('');
    setUploadProgress(0);
    setUploadPhase('idle');
    if (videoInputRef.current) {
      videoInputRef.current.value = '';
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;

    setLoading(true);
    setError('');

    try {
      if (postType === 'video') {
        if (!videoFile) {
          setError('Please choose a video file to publish');
          setLoading(false);
          return;
        }

        // 1. Upload to Cloudinary with live progress
        setUploadPhase('uploading');
        setUploadProgress(0);

        const cloudinaryResult = await storageService.uploadVideo(
          videoFile,
          (percent) => {
            setUploadProgress(percent);
            if (percent >= 99) {
              setUploadPhase('processing');
            }
          }
        );

        if (!cloudinaryResult.videoUrl) {
          throw new Error('Cloudinary did not return a valid video URL');
        }

        // 2. Parse tags
        const parsedTags = tagsInput
          .split(/[\s,]+/)
          .map((t) => t.replace('#', '').trim())
          .filter(Boolean);

        // 3. Create video document in Firestore
        await videosService.createVideo({
          userId: currentUser.id,
          user: {
            id: currentUser.id,
            username: currentUser.username,
            displayName: currentUser.displayName,
            avatarUrl: currentUser.avatarUrl,
            isVerified: currentUser.isVerified,
          },
          videoUrl: cloudinaryResult.videoUrl,
          thumbnailUrl: cloudinaryResult.thumbnailUrl,
          caption: caption.trim(),
          tags: parsedTags,
          duration: cloudinaryResult.duration,
        });

        // 4. Success callback
        onCreated('video');
      } else if (postType === 'story') {
        if (!imageUrl) {
          setError('Please provide an image for your story');
          setLoading(false);
          return;
        }

        await storiesService.createStory(
          {
            id: currentUser.id,
            username: currentUser.username,
            displayName: currentUser.displayName,
            avatarUrl: currentUser.avatarUrl,
          },
          imageUrl
        );
        onCreated('story');
      } else {
        // Feed post
        if (!imageUrl) {
          setError('Please provide an image for your post');
          setLoading(false);
          return;
        }

        const parsedTags = tagsInput
          .split(/[\s,]+/)
          .map((t) => t.replace('#', '').trim())
          .filter(Boolean);

        await postsService.createPost({
          userId: currentUser.id,
          user: {
            id: currentUser.id,
            username: currentUser.username,
            displayName: currentUser.displayName,
            avatarUrl: currentUser.avatarUrl,
            isVerified: currentUser.isVerified,
          },
          imageUrl,
          caption: caption.trim(),
          tags: parsedTags,
          location: location.trim() || undefined,
        });
        onCreated('feed');
      }
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Failed to publish. Please try again.');
    } finally {
      setLoading(false);
      setUploadPhase('idle');
    }
  };

  return (
    <div className="bg-slate-900 rounded-3xl border border-slate-800 p-5 sm:p-8 shadow-sm">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 mb-6 border-b border-slate-800 gap-3">
        <div>
          <h1 className="text-xl font-bold text-white">New Publication</h1>
          <p className="text-xs text-slate-400 mt-0.5">Share with the Sogo community</p>
        </div>

        {/* Type Toggle: Feed vs Story vs Video */}
        <div className="flex bg-slate-800/90 border border-slate-700/60 p-1 rounded-xl">
          <button
            type="button"
            onClick={() => {
              setPostType('feed');
              setError('');
            }}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              postType === 'feed'
                ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-xs'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Feed
          </button>
          <button
            type="button"
            onClick={() => {
              setPostType('story');
              setError('');
            }}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              postType === 'story'
                ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-xs'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Story
          </button>
          <button
            type="button"
            onClick={() => {
              setPostType('video');
              setError('');
            }}
            className={`flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              postType === 'video'
                ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-xs'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Film className="w-3.5 h-3.5" />
            <span>Video Reel</span>
          </button>
        </div>
      </div>

      {error && (
        <div className="mb-4 p-3 bg-rose-950/40 text-rose-300 rounded-xl text-xs font-medium border border-rose-800/60 flex items-center justify-between">
          <span>{error}</span>
          <button
            type="button"
            onClick={() => setError('')}
            className="text-rose-400 hover:text-rose-200 font-bold ml-2 text-xs"
          >
            Dismiss
          </button>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* VIDEO UPLOAD SECTION */}
        {postType === 'video' ? (
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
              Video File (Required)
            </label>

            {videoPreviewUrl ? (
              <div className="relative rounded-2xl overflow-hidden bg-black border border-slate-800 flex flex-col items-center justify-center p-2">
                <video
                  src={videoPreviewUrl}
                  controls
                  playsInline
                  className="max-h-80 w-auto rounded-xl object-contain bg-black"
                />
                <div className="w-full flex items-center justify-between px-3 py-2 mt-2 bg-slate-950/60 rounded-xl">
                  <span className="text-xs text-slate-300 truncate max-w-[200px]">
                    {videoFile?.name} ({(videoFile ? videoFile.size / (1024 * 1024) : 0).toFixed(1)} MB)
                  </span>
                  <button
                    type="button"
                    onClick={handleClearVideo}
                    disabled={loading}
                    className="px-3 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-semibold border border-slate-700 transition-colors cursor-pointer"
                  >
                    Change Video
                  </button>
                </div>
              </div>
            ) : (
              <div className="border-2 border-dashed border-slate-800 bg-slate-950/40 rounded-2xl p-6 sm:p-8 text-center hover:border-cyan-500 transition-colors">
                <input
                  ref={videoInputRef}
                  type="file"
                  accept="video/*"
                  onChange={handleVideoSelect}
                  id="video-file-input"
                  className="hidden"
                />
                <label
                  htmlFor="video-file-input"
                  className="flex flex-col items-center justify-center cursor-pointer group"
                >
                  <div className="w-14 h-14 rounded-2xl bg-cyan-950/50 text-cyan-400 border border-cyan-800/40 flex items-center justify-center mb-3 group-hover:scale-105 transition-transform shadow-lg shadow-cyan-950/20">
                    <Video className="w-7 h-7" />
                  </div>
                  <p className="text-sm font-bold text-white">
                    Select video from device
                  </p>
                  <p className="text-xs text-slate-400 mt-1">
                    MP4, WebM, QuickTime up to 100MB
                  </p>
                  <span className="mt-4 inline-flex items-center gap-1.5 px-4 py-2 bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-400 text-xs font-bold rounded-xl border border-cyan-500/30 transition-colors">
                    <UploadCloud className="w-4 h-4" />
                    Browse Gallery
                  </span>
                </label>
              </div>
            )}

            {/* Upload Progress Bar */}
            {uploadPhase !== 'idle' && (
              <div className="mt-4 p-4 bg-slate-950/80 rounded-2xl border border-cyan-500/30 space-y-2">
                <div className="flex items-center justify-between text-xs font-semibold text-slate-300">
                  <span>
                    {uploadPhase === 'uploading'
                      ? `Uploading to Cloudinary... ${uploadProgress}%`
                      : 'Processing video on Cloudinary...'}
                  </span>
                  <span className="text-cyan-400">{uploadProgress}%</span>
                </div>
                <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-cyan-400 to-blue-500 transition-all duration-200"
                    style={{ width: `${uploadProgress}%` }}
                  />
                </div>
              </div>
            )}
          </div>
        ) : (
          /* EXISTING IMAGE UPLOAD SECTION (100% PRESERVED) */
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
              Media Asset (Required)
            </label>

            {imageUrl ? (
              <div className="relative aspect-16/10 rounded-2xl overflow-hidden bg-slate-950 group border border-slate-800">
                <img
                  src={imageUrl}
                  alt="Upload preview"
                  className="w-full h-full object-cover"
                />
                <button
                  type="button"
                  onClick={() => setImageUrl('')}
                  className="absolute top-3 right-3 px-3 py-1.5 bg-black/70 hover:bg-black/90 text-white rounded-full text-xs font-semibold backdrop-blur-xs border border-white/20 transition-colors cursor-pointer"
                >
                  Change Image
                </button>
              </div>
            ) : (
              <div className="border-2 border-dashed border-slate-800 bg-slate-950/40 rounded-2xl p-6 sm:p-8 text-center hover:border-cyan-500 transition-colors">
                <input
                  ref={imageInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleImageUpload}
                  id="image-file-input"
                  className="hidden"
                />
                <label
                  htmlFor="image-file-input"
                  className="flex flex-col items-center justify-center cursor-pointer group"
                >
                  <div className="w-12 h-12 rounded-2xl bg-cyan-950/50 text-cyan-400 border border-cyan-800/40 flex items-center justify-center mb-3 group-hover:scale-105 transition-transform">
                    <UploadCloud className="w-6 h-6" />
                  </div>
                  <p className="text-sm font-bold text-white">
                    Click to upload from device
                  </p>
                  <p className="text-xs text-slate-400 mt-1">PNG, JPG, WebP up to 10MB</p>
                </label>

                {/* Presets for Instant Testing */}
                <div className="mt-6 pt-4 border-t border-slate-800">
                  <p className="text-xs text-slate-400 mb-2 flex items-center justify-center gap-1">
                    <Sparkles className="w-3 h-3 text-cyan-400" />
                    Or pick a curated sample photo:
                  </p>
                  <div className="flex items-center justify-center gap-2">
                    {PRESET_PHOTOS.map((src, idx) => (
                      <img
                        key={idx}
                        src={src}
                        alt="Preset option"
                        onClick={() => setImageUrl(src)}
                        className="w-12 h-12 rounded-lg object-cover cursor-pointer hover:ring-2 hover:ring-cyan-400 transition-all hover:scale-105"
                      />
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Caption (for Feed and Video posts) */}
        {postType !== 'story' && (
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
              Caption & Description
            </label>
            <textarea
              rows={3}
              value={caption}
              onChange={(e) => setCaption(e.target.value)}
              placeholder={
                postType === 'video'
                  ? 'Add a caption for your video reel... #trending #sogo'
                  : 'What is the story behind this visual?'
              }
              className="w-full p-3.5 bg-slate-800/60 border border-slate-700/80 rounded-2xl text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 resize-none"
            />
          </div>
        )}

        {/* Tags (for Feed and Video posts) */}
        {postType !== 'story' && (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {postType === 'feed' && (
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-1.5 flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5 text-cyan-400" />
                  Location
                </label>
                <input
                  type="text"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  placeholder="e.g. Kyoto, Japan"
                  className="w-full px-3.5 py-2.5 bg-slate-800/60 border border-slate-700/80 rounded-xl text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500"
                />
              </div>
            )}

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-1.5 flex items-center gap-1">
                <Hash className="w-3.5 h-3.5 text-cyan-400" />
                Tags
              </label>
              <input
                type="text"
                value={tagsInput}
                onChange={(e) => setTagsInput(e.target.value)}
                placeholder="reels, travel, creative"
                className="w-full px-3.5 py-2.5 bg-slate-800/60 border border-slate-700/80 rounded-xl text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500"
              />
            </div>
          </div>
        )}

        {/* Actions */}
        <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-800">
          {onCancel && (
            <Button variant="ghost" size="md" onClick={onCancel} disabled={loading}>
              Cancel
            </Button>
          )}
          <Button
            type="submit"
            variant="primary"
            size="md"
            isLoading={loading}
            rightIcon={<Check className="w-4 h-4" />}
            disabled={
              postType === 'video'
                ? !videoFile || loading
                : !imageUrl || loading
            }
          >
            {postType === 'video'
              ? 'Publish Video Reel'
              : postType === 'story'
              ? 'Share Story'
              : 'Publish Post'}
          </Button>
        </div>
      </form>
    </div>
  );
};
