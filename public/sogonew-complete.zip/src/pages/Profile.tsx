import React, { useState, useEffect } from 'react';
import { User, Post, VideoPost } from '../types';
import { ProfileHeader } from '../components/ProfileHeader';
import { ImageGrid } from '../components/ImageGrid';
import { LoadingState } from '../components/LoadingState';
import { Button } from '../components/Button';
import { useAuth } from '../hooks/useAuth';
import { Login } from './Login';
import * as postsService from '../services/postsService';
import * as usersService from '../services/usersService';
import * as videosService from '../services/videosService';
import { Grid, Bookmark, Heart, X, Check, Film, Play, Eye } from 'lucide-react';

export interface ProfileProps {
  userId?: string;
  onPostClick: (post: Post) => void;
  onSettingsClick: () => void;
  onNavigateVideos?: () => void;
}

export const Profile: React.FC<ProfileProps> = ({
  userId,
  onPostClick,
  onSettingsClick,
  onNavigateVideos,
}) => {
  const { currentUser, updateProfile } = useAuth();
  const [profileUser, setProfileUser] = useState<User | null>(null);
  const [userPosts, setUserPosts] = useState<Post[]>([]);
  const [savedPosts, setSavedPosts] = useState<Post[]>([]);
  const [userVideos, setUserVideos] = useState<VideoPost[]>([]);
  const [selectedVideoModal, setSelectedVideoModal] = useState<VideoPost | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'posts' | 'videos' | 'saved' | 'liked'>('posts');
  const [isEditing, setIsEditing] = useState(false);

  // Edit form states
  const [editDisplayName, setEditDisplayName] = useState('');
  const [editBio, setEditBio] = useState('');
  const [editWebsite, setEditWebsite] = useState('');
  const [editAvatarUrl, setEditAvatarUrl] = useState('');

  const isViewingOwnProfile = !userId || (Boolean(currentUser && userId === currentUser.id));

  // If viewing own profile and unauthenticated, show Sign In / Sign Up screen
  if (isViewingOwnProfile && !currentUser) {
    return (
      <div className="py-4">
        <Login standalone={false} />
      </div>
    );
  }

  const targetId = userId || currentUser?.id;
  const isCurrentUser = Boolean(currentUser && currentUser.id === targetId);

  useEffect(() => {
    async function loadProfile() {
      if (!targetId) {
        setLoading(false);
        return;
      }

      setLoading(true);
      try {
        const user = isCurrentUser && currentUser
          ? currentUser
          : await usersService.getUser(targetId);

        setProfileUser(user);

        if (user) {
          const [posts, bookmarks, videos] = await Promise.all([
            postsService.getUserPosts(user.id),
            postsService.getBookmarkedPosts(),
            videosService.getUserVideos(user.id),
          ]);
          setUserPosts(posts);
          setSavedPosts(bookmarks);
          setUserVideos(videos);

          setEditDisplayName(user.displayName);
          setEditBio(user.bio || '');
          setEditWebsite(user.website || '');
          setEditAvatarUrl(user.avatarUrl);
        }
      } finally {
        setLoading(false);
      }
    }
    loadProfile();
  }, [targetId, isCurrentUser, currentUser]);

  const handleFollowToggle = async (uid: string) => {
    const isNowFollowing = await usersService.toggleFollowUser(uid);
    setProfileUser((prev) =>
      prev
        ? {
            ...prev,
            isFollowing: isNowFollowing,
            followersCount: isNowFollowing
              ? prev.followersCount + 1
              : Math.max(0, prev.followersCount - 1),
          }
        : null
    );
  };

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!profileUser) return;
    const updatedData = {
      displayName: editDisplayName.trim(),
      bio: editBio.trim(),
      website: editWebsite.trim(),
      avatarUrl: editAvatarUrl.trim(),
    };
    await usersService.updateUserProfile(profileUser.id, updatedData);
    setProfileUser((prev) => (prev ? { ...prev, ...updatedData } : null));
    if (isCurrentUser) {
      updateProfile(updatedData);
    }
    setIsEditing(false);
  };

  if (loading) {
    return <LoadingState message="Loading profile..." />;
  }

  if (!profileUser) {
    return (
      <div className="py-12 text-center text-slate-400">
        <p className="text-sm">Profile not found.</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <ProfileHeader
        user={profileUser}
        isCurrentUser={isCurrentUser}
        onEditProfile={() => setIsEditing(true)}
        onFollowToggle={handleFollowToggle}
        onSettingsClick={onSettingsClick}
      />

      {/* Tabs */}
      <div className="flex border-b border-slate-800">
        <button
          type="button"
          onClick={() => setActiveTab('posts')}
          className={`flex-1 py-3 text-xs sm:text-sm font-bold flex items-center justify-center gap-2 border-b-2 transition-colors cursor-pointer ${
            activeTab === 'posts'
              ? 'border-cyan-400 text-cyan-400'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <Grid className="w-4 h-4" />
          <span>Posts ({userPosts.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('videos')}
          className={`flex-1 py-3 text-xs sm:text-sm font-bold flex items-center justify-center gap-2 border-b-2 transition-colors cursor-pointer ${
            activeTab === 'videos'
              ? 'border-cyan-400 text-cyan-400'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <Film className="w-4 h-4" />
          <span>Videos ({userVideos.length})</span>
        </button>

        {isCurrentUser && (
          <button
            type="button"
            onClick={() => setActiveTab('saved')}
            className={`flex-1 py-3 text-xs sm:text-sm font-bold flex items-center justify-center gap-2 border-b-2 transition-colors cursor-pointer ${
              activeTab === 'saved'
                ? 'border-cyan-400 text-cyan-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Bookmark className="w-4 h-4" />
            <span>Saved ({savedPosts.length})</span>
          </button>
        )}

        <button
          type="button"
          onClick={() => setActiveTab('liked')}
          className={`flex-1 py-3 text-xs sm:text-sm font-bold flex items-center justify-center gap-2 border-b-2 transition-colors cursor-pointer ${
            activeTab === 'liked'
              ? 'border-cyan-400 text-cyan-400'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <Heart className="w-4 h-4" />
          <span>Appreciated</span>
        </button>
      </div>

      {/* Tab Content */}
      <div>
        {activeTab === 'posts' && (
          <ImageGrid
            posts={userPosts}
            onPostClick={onPostClick}
            emptyMessage="No visual moments shared yet."
          />
        )}

        {activeTab === 'videos' && (
          userVideos.length === 0 ? (
            <div className="py-14 text-center text-slate-400">
              <Film className="w-10 h-10 mx-auto text-slate-600 mb-2 stroke-[1.5]" />
              <p className="text-sm font-medium">No videos published yet</p>
              {isCurrentUser && onNavigateVideos && (
                <button
                  type="button"
                  onClick={onNavigateVideos}
                  className="mt-3 inline-flex items-center gap-1.5 px-4 py-2 bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-400 rounded-xl text-xs font-bold border border-cyan-500/30 transition-colors cursor-pointer"
                >
                  Go to Reels
                </button>
              )}
            </div>
          ) : (
            <div className="grid grid-cols-3 gap-1.5 sm:gap-3">
              {userVideos.map((video) => (
                <div
                  key={video.id}
                  onClick={() => setSelectedVideoModal(video)}
                  className="relative aspect-9/16 rounded-xl overflow-hidden bg-slate-950 group cursor-pointer border border-slate-800/80 hover:border-cyan-500/50 transition-all"
                >
                  {video.thumbnailUrl ? (
                    <img
                      src={video.thumbnailUrl}
                      alt={video.caption || 'Video'}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                  ) : (
                    <div className="w-full h-full bg-slate-900 flex items-center justify-center text-slate-600">
                      <Film className="w-6 h-6" />
                    </div>
                  )}

                  {/* Play badge */}
                  <div className="absolute top-2 right-2 w-6 h-6 rounded-full bg-black/60 backdrop-blur-sm flex items-center justify-center text-white">
                    <Play className="w-3 h-3 fill-white ml-0.5" />
                  </div>

                  {/* Views & Likes count overlay */}
                  <div className="absolute bottom-0 inset-x-0 p-2 bg-gradient-to-t from-black/80 to-transparent flex items-center justify-between text-[10px] text-white font-semibold">
                    <span className="flex items-center gap-1">
                      <Eye className="w-3 h-3 text-cyan-400" />
                      {video.viewsCount}
                    </span>
                    <span className="flex items-center gap-1">
                      <Heart className="w-3 h-3 text-red-400 fill-red-400" />
                      {video.likesCount}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )
        )}

        {activeTab === 'saved' && (
          <ImageGrid
            posts={savedPosts}
            onPostClick={onPostClick}
            emptyMessage="No saved bookmarks."
          />
        )}

        {activeTab === 'liked' && (
          <ImageGrid
            posts={userPosts.filter((p) => p.likesCount > 0)}
            onPostClick={onPostClick}
            emptyMessage="No liked posts yet."
          />
        )}
      </div>

      {/* Video Preview Modal */}
      {selectedVideoModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="relative max-w-sm w-full bg-black rounded-3xl overflow-hidden border border-slate-800 shadow-2xl flex flex-col">
            <div className="absolute top-3 right-3 z-30">
              <button
                type="button"
                onClick={() => setSelectedVideoModal(null)}
                className="w-8 h-8 rounded-full bg-black/60 text-white flex items-center justify-center hover:bg-black/90 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <video
              src={selectedVideoModal.videoUrl}
              controls
              autoPlay
              playsInline
              className="w-full aspect-9/16 object-contain bg-black"
            />
            {selectedVideoModal.caption && (
              <div className="p-4 bg-slate-900 border-t border-slate-800">
                <p className="text-xs text-white line-clamp-2">
                  {selectedVideoModal.caption}
                </p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Edit Profile Modal */}
      {isEditing && (
        <div className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center p-4 backdrop-blur-xs">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 max-w-md w-full shadow-2xl space-y-4 text-slate-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h2 className="font-bold text-base text-white">Edit Profile</h2>
              <button
                type="button"
                onClick={() => setIsEditing(false)}
                className="p-1 rounded-full text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveProfile} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">Display Name</label>
                <input
                  type="text"
                  value={editDisplayName}
                  onChange={(e) => setEditDisplayName(e.target.value)}
                  className="w-full px-3.5 py-2 bg-slate-800/80 border border-slate-700 rounded-xl text-sm text-slate-100 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">Bio</label>
                <textarea
                  rows={3}
                  value={editBio}
                  onChange={(e) => setEditBio(e.target.value)}
                  placeholder="Share a short summary about your craft..."
                  className="w-full px-3.5 py-2 bg-slate-800/80 border border-slate-700 rounded-xl text-sm text-slate-100 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 resize-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">Website</label>
                <input
                  type="url"
                  value={editWebsite}
                  onChange={(e) => setEditWebsite(e.target.value)}
                  placeholder="https://yourportfolio.com"
                  className="w-full px-3.5 py-2 bg-slate-800/80 border border-slate-700 rounded-xl text-sm text-slate-100 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">Avatar Image URL</label>
                <input
                  type="url"
                  value={editAvatarUrl}
                  onChange={(e) => setEditAvatarUrl(e.target.value)}
                  className="w-full px-3.5 py-2 bg-slate-800/80 border border-slate-700 rounded-xl text-sm text-slate-100 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
                <Button variant="ghost" size="sm" onClick={() => setIsEditing(false)}>
                  Cancel
                </Button>
                <Button type="submit" variant="primary" size="sm" rightIcon={<Check className="w-4 h-4" />}>
                  Save Changes
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
