import { User } from '../types';

const USERS_STORAGE_KEY = 'sogo_users_cache';

export const INITIAL_USERS: User[] = [
  {
    id: 'user_1',
    username: 'azlan',
    displayName: 'Azlan Malik',
    email: 'azlanmalik774@gmail.com',
    avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&auto=format&fit=crop&q=80',
    bio: 'Software engineer, DevOps & product creator. Crafting modern visual experiences.',
    website: 'https://azlanmalik.com',
    followersCount: 1420,
    followingCount: 380,
    postsCount: 24,
    isFollowing: false,
    isVerified: true,
    createdAt: new Date(Date.now() - 90 * 86400000).toISOString(),
  },
  {
    id: 'user_2',
    username: 'maya_lens',
    displayName: 'Maya Chen',
    email: 'maya@example.com',
    avatarUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=300&auto=format&fit=crop&q=80',
    bio: 'Film photographer & visual poet. Chasing golden hour in Tokyo & SF.',
    website: 'https://mayachen.photo',
    followersCount: 8900,
    followingCount: 420,
    postsCount: 68,
    isFollowing: true,
    isVerified: true,
    createdAt: new Date(Date.now() - 120 * 86400000).toISOString(),
  },
  {
    id: 'user_3',
    username: 'alex_design',
    displayName: 'Alex Rivers',
    email: 'alex@example.com',
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&auto=format&fit=crop&q=80',
    bio: 'Design systems lead & typography obsessive. Form follows emotion.',
    website: 'https://rivers.design',
    followersCount: 4320,
    followingCount: 512,
    postsCount: 39,
    isFollowing: false,
    isVerified: false,
    createdAt: new Date(Date.now() - 45 * 86400000).toISOString(),
  },
  {
    id: 'user_4',
    username: 'sophia_travel',
    displayName: 'Sophia Laurent',
    email: 'sophia@example.com',
    avatarUrl: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=300&auto=format&fit=crop&q=80',
    bio: 'Wanderlust explorer ✈️ Traveling across 34 countries and counting.',
    followersCount: 12500,
    followingCount: 610,
    postsCount: 112,
    isFollowing: true,
    isVerified: true,
    createdAt: new Date(Date.now() - 200 * 86400000).toISOString(),
  },
  {
    id: 'user_5',
    username: 'kai_tokyo',
    displayName: 'Kai Sato',
    email: 'kai@example.com',
    avatarUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=300&auto=format&fit=crop&q=80',
    bio: 'Cyberpunk street scenes, night architecture and matcha latte aficionado.',
    followersCount: 6700,
    followingCount: 290,
    postsCount: 45,
    isFollowing: false,
    isVerified: false,
    createdAt: new Date(Date.now() - 60 * 86400000).toISOString(),
  }
];

function getStoredUsers(): User[] {
  try {
    const raw = localStorage.getItem(USERS_STORAGE_KEY);
    if (raw) {
      return JSON.parse(raw);
    }
  } catch (e) {
    console.error('Failed to load users from localStorage', e);
  }
  return INITIAL_USERS;
}

function saveUsers(users: User[]) {
  try {
    localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(users));
  } catch (e) {
    console.error('Failed to save users to localStorage', e);
  }
}

export async function getUser(userId: string): Promise<User | null> {
  const users = getStoredUsers();
  return users.find((u) => u.id === userId || u.username === userId) || null;
}

export async function getSuggestedUsers(excludeUserId?: string): Promise<User[]> {
  const users = getStoredUsers();
  return users.filter((u) => u.id !== excludeUserId);
}

export async function searchUsers(query: string): Promise<User[]> {
  const trimmed = query.trim().toLowerCase();
  if (!trimmed) return [];
  const users = getStoredUsers();
  return users.filter(
    (u) =>
      u.username.toLowerCase().includes(trimmed) ||
      u.displayName.toLowerCase().includes(trimmed) ||
      (u.bio && u.bio.toLowerCase().includes(trimmed))
  );
}

export async function toggleFollowUser(targetUserId: string): Promise<boolean> {
  const users = getStoredUsers();
  let newStatus = false;
  const updated = users.map((u) => {
    if (u.id === targetUserId) {
      newStatus = !u.isFollowing;
      return {
        ...u,
        isFollowing: newStatus,
        followersCount: newStatus ? u.followersCount + 1 : Math.max(0, u.followersCount - 1),
      };
    }
    return u;
  });
  saveUsers(updated);
  return newStatus;
}

export async function updateUserProfile(userId: string, data: Partial<User>): Promise<User> {
  const users = getStoredUsers();
  let updatedUser: User | null = null;
  const updated = users.map((u) => {
    if (u.id === userId) {
      updatedUser = { ...u, ...data };
      return updatedUser;
    }
    return u;
  });
  if (!updatedUser) {
    throw new Error('User not found');
  }
  saveUsers(updated);
  return updatedUser;
}
