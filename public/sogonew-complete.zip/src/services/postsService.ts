import { Post, Comment } from '../types';

const POSTS_STORAGE_KEY = 'sogo_posts_cache';
const COMMENTS_STORAGE_KEY = 'sogo_comments_cache';

const INITIAL_POSTS: Post[] = [
  {
    id: 'post_1',
    userId: 'user_2',
    user: {
      id: 'user_2',
      username: 'maya_lens',
      displayName: 'Maya Chen',
      avatarUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=300&auto=format&fit=crop&q=80',
      isVerified: true,
    },
    imageUrl: 'https://images.unsplash.com/photo-1514565131-fce0801e5785?w=1200&auto=format&fit=crop&q=80',
    caption: 'Neon reflections in Shinjuku alleys after the rain. There is a quiet magic in the city when the crowds disperse. 🏮✨ #tokyo #filmphotography #cinematic',
    tags: ['tokyo', 'filmphotography', 'cinematic'],
    location: 'Shinjuku, Tokyo, Japan',
    likesCount: 342,
    commentsCount: 28,
    isLiked: false,
    isBookmarked: false,
    createdAt: new Date(Date.now() - 3 * 3600000).toISOString(),
  },
  {
    id: 'post_2',
    userId: 'user_1',
    user: {
      id: 'user_1',
      username: 'azlan',
      displayName: 'Azlan Malik',
      avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&auto=format&fit=crop&q=80',
      isVerified: true,
    },
    imageUrl: 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?w=1200&auto=format&fit=crop&q=80',
    caption: 'Clean workspace, cold brew, and shipping features. The Sogo design system is coming together so smoothly. 💻☕️',
    tags: ['developer', 'workspace', 'minimalism'],
    location: 'San Francisco, CA',
    likesCount: 512,
    commentsCount: 42,
    isLiked: true,
    isBookmarked: true,
    createdAt: new Date(Date.now() - 7 * 3600000).toISOString(),
  },
  {
    id: 'post_3',
    userId: 'user_4',
    user: {
      id: 'user_4',
      username: 'sophia_travel',
      displayName: 'Sophia Laurent',
      avatarUrl: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=300&auto=format&fit=crop&q=80',
      isVerified: true,
    },
    imageUrl: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?w=1200&auto=format&fit=crop&q=80',
    caption: 'Early sunrise mist over the alpine peaks. Woke up at 4:30 AM for this hike and it was worth every single step. 🏔️🌤️',
    tags: ['adventure', 'nature', 'alps'],
    location: 'Dolomites, Italy',
    likesCount: 890,
    commentsCount: 65,
    isLiked: false,
    isBookmarked: false,
    createdAt: new Date(Date.now() - 14 * 3600000).toISOString(),
  },
  {
    id: 'post_4',
    userId: 'user_3',
    user: {
      id: 'user_3',
      username: 'alex_design',
      displayName: 'Alex Rivers',
      avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&auto=format&fit=crop&q=80',
      isVerified: false,
    },
    imageUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=1200&auto=format&fit=crop&q=80',
    caption: 'Fluid typography experiments and organic curves. Balancing mathematical grid precision with emotional warmth. 🎨📐',
    tags: ['graphicdesign', 'generative', '3d'],
    location: 'Design Studio, Berlin',
    likesCount: 418,
    commentsCount: 19,
    isLiked: false,
    isBookmarked: false,
    createdAt: new Date(Date.now() - 24 * 3600000).toISOString(),
  }
];

const INITIAL_COMMENTS: Record<string, Comment[]> = {
  post_1: [
    {
      id: 'com_1',
      postId: 'post_1',
      userId: 'user_1',
      user: {
        id: 'user_1',
        username: 'azlan',
        displayName: 'Azlan Malik',
        avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&auto=format&fit=crop&q=80',
      },
      text: 'The color grading on this is breathtaking! What lens did you shoot this with?',
      createdAt: new Date(Date.now() - 2 * 3600000).toISOString(),
      likesCount: 12,
    },
    {
      id: 'com_2',
      postId: 'post_1',
      userId: 'user_3',
      user: {
        id: 'user_3',
        username: 'alex_design',
        displayName: 'Alex Rivers',
        avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&auto=format&fit=crop&q=80',
      },
      text: 'Blade Runner vibes. Absolutely stunning composition.',
      createdAt: new Date(Date.now() - 1 * 3600000).toISOString(),
      likesCount: 4,
    }
  ]
};

function getStoredPosts(): Post[] {
  try {
    const raw = localStorage.getItem(POSTS_STORAGE_KEY);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.error('Failed to get posts from storage', e);
  }
  return INITIAL_POSTS;
}

function savePosts(posts: Post[]) {
  try {
    localStorage.setItem(POSTS_STORAGE_KEY, JSON.stringify(posts));
  } catch (e) {
    console.error('Failed to save posts to storage', e);
  }
}

function getStoredComments(): Record<string, Comment[]> {
  try {
    const raw = localStorage.getItem(COMMENTS_STORAGE_KEY);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.error('Failed to get comments from storage', e);
  }
  return INITIAL_COMMENTS;
}

function saveComments(comments: Record<string, Comment[]>) {
  try {
    localStorage.setItem(COMMENTS_STORAGE_KEY, JSON.stringify(comments));
  } catch (e) {
    console.error('Failed to save comments to storage', e);
  }
}

export async function getFeedPosts(): Promise<Post[]> {
  return getStoredPosts();
}

export async function getPostById(postId: string): Promise<Post | null> {
  const posts = getStoredPosts();
  return posts.find((p) => p.id === postId) || null;
}

export async function getUserPosts(userId: string): Promise<Post[]> {
  const posts = getStoredPosts();
  return posts.filter((p) => p.userId === userId || p.user.username === userId);
}

export async function getBookmarkedPosts(): Promise<Post[]> {
  const posts = getStoredPosts();
  return posts.filter((p) => p.isBookmarked);
}

export async function createPost(
  newPostData: Omit<Post, 'id' | 'likesCount' | 'commentsCount' | 'createdAt'>
): Promise<Post> {
  const posts = getStoredPosts();
  const created: Post = {
    ...newPostData,
    id: `post_${Date.now()}`,
    likesCount: 0,
    commentsCount: 0,
    isLiked: false,
    isBookmarked: false,
    createdAt: new Date().toISOString(),
  };
  const updated = [created, ...posts];
  savePosts(updated);
  return created;
}

export async function toggleLikePost(postId: string): Promise<{ isLiked: boolean; likesCount: number }> {
  const posts = getStoredPosts();
  let result = { isLiked: false, likesCount: 0 };
  const updated = posts.map((p) => {
    if (p.id === postId) {
      const nextLiked = !p.isLiked;
      const nextCount = nextLiked ? p.likesCount + 1 : Math.max(0, p.likesCount - 1);
      result = { isLiked: nextLiked, likesCount: nextCount };
      return {
        ...p,
        isLiked: nextLiked,
        likesCount: nextCount,
      };
    }
    return p;
  });
  savePosts(updated);
  return result;
}

export async function toggleBookmarkPost(postId: string): Promise<boolean> {
  const posts = getStoredPosts();
  let result = false;
  const updated = posts.map((p) => {
    if (p.id === postId) {
      const nextBookmarked = !p.isBookmarked;
      result = nextBookmarked;
      return {
        ...p,
        isBookmarked: nextBookmarked,
      };
    }
    return p;
  });
  savePosts(updated);
  return result;
}

export async function getComments(postId: string): Promise<Comment[]> {
  const allComments = getStoredComments();
  return allComments[postId] || [];
}

export async function addComment(
  postId: string,
  user: Comment['user'],
  text: string
): Promise<Comment> {
  const allComments = getStoredComments();
  const postComments = allComments[postId] || [];
  const newComment: Comment = {
    id: `com_${Date.now()}`,
    postId,
    userId: user.id,
    user,
    text,
    createdAt: new Date().toISOString(),
    likesCount: 0,
  };
  allComments[postId] = [...postComments, newComment];
  saveComments(allComments);

  // Update comment counter on the post
  const posts = getStoredPosts();
  const updatedPosts = posts.map((p) =>
    p.id === postId ? { ...p, commentsCount: p.commentsCount + 1 } : p
  );
  savePosts(updatedPosts);

  return newComment;
}

export async function deletePost(postId: string): Promise<void> {
  const posts = getStoredPosts();
  savePosts(posts.filter((p) => p.id !== postId));
}
