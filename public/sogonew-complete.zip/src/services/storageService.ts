/**
 * Cloudinary Storage Service for Sogo.
 * Handles existing image uploads and adds Cloudinary video uploads with progress tracking.
 */

export interface VideoUploadResult {
  videoUrl: string;
  thumbnailUrl: string;
  duration?: number;
  publicId?: string;
  format?: string;
}

// Configuration from environment variables
const CLOUDINARY_CLOUD_NAME = (
  import.meta.env.VITE_CLOUDINARY_CLOUD_NAME ||
  (typeof process !== 'undefined' ? process.env?.VITE_CLOUDINARY_CLOUD_NAME : '') ||
  'eiwwjhkq'
).trim();

const CLOUDINARY_UPLOAD_PRESET = (
  import.meta.env.VITE_CLOUDINARY_UPLOAD_PRESET ||
  (typeof process !== 'undefined' ? process.env?.VITE_CLOUDINARY_UPLOAD_PRESET : '') ||
  'sogo_upload'
).trim();

const CLOUDINARY_VIDEO_PRESET = (
  import.meta.env.VITE_CLOUDINARY_VIDEO_PRESET ||
  (typeof process !== 'undefined' ? process.env?.VITE_CLOUDINARY_VIDEO_PRESET : '') ||
  CLOUDINARY_UPLOAD_PRESET ||
  'sogo_upload'
).trim();

/**
 * Preserved existing image upload implementation.
 * Converts image file to Data URL / string representation.
 */
export async function uploadImage(file: File | Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        resolve(reader.result);
      } else {
        reject(new Error('Failed to convert file to data URL'));
      }
    };
    reader.onerror = (error) => reject(error);
    reader.readAsDataURL(file);
  });
}

/**
 * Uploads an avatar image using Cloudinary unsigned preset when available,
 * with fallback to Data URL representation.
 */
export async function uploadAvatarImage(file: File | Blob): Promise<string> {
  if (file.type && !file.type.startsWith('image/')) {
    throw new Error('Please select a valid image file (JPEG, PNG, WebP).');
  }

  // Attempt upload to Cloudinary if credentials are configured
  if (CLOUDINARY_CLOUD_NAME && CLOUDINARY_UPLOAD_PRESET) {
    try {
      const uploadUrl = `https://api.cloudinary.com/v1_1/${CLOUDINARY_CLOUD_NAME}/image/upload`;
      const formData = new FormData();
      formData.append('file', file);
      formData.append('upload_preset', CLOUDINARY_UPLOAD_PRESET);

      const response = await fetch(uploadUrl, {
        method: 'POST',
        body: formData,
      });

      if (response.ok) {
        const data = await response.json();
        if (data.secure_url) {
          return data.secure_url;
        }
      }
    } catch (err) {
      console.warn('Cloudinary avatar upload note, using local fallback:', err);
    }
  }

  // Fallback to existing image upload
  return uploadImage(file);
}

/**
 * Uploads a video file directly to Cloudinary using unsigned upload preset.
 * Reports upload progress via optional onProgress callback (0-100%).
 * Generates an automatic video poster/thumbnail URL from Cloudinary.
 */
export async function uploadVideo(
  file: File | Blob,
  onProgress?: (percent: number) => void
): Promise<VideoUploadResult> {
  // 1. File validation
  const MAX_VIDEO_SIZE = 100 * 1024 * 1024; // 100MB limit for mobile uploads
  if (file.size > MAX_VIDEO_SIZE) {
    throw new Error('Video file is too large. Please select a video smaller than 100MB.');
  }

  // 2. Prepare Cloudinary request
  const uploadUrl = `https://api.cloudinary.com/v1_1/${CLOUDINARY_CLOUD_NAME}/video/upload`;
  const formData = new FormData();
  formData.append('file', file);
  formData.append('upload_preset', CLOUDINARY_VIDEO_PRESET);

  // 3. Perform upload with XMLHttpRequest for reliable progress reporting
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open('POST', uploadUrl);

    if (xhr.upload && onProgress) {
      xhr.upload.onprogress = (event) => {
        if (event.lengthComputable) {
          const percent = Math.round((event.loaded / event.total) * 100);
          onProgress(percent);
        }
      };
    }

    xhr.onload = () => {
      try {
        const response = JSON.parse(xhr.responseText);
        if (xhr.status >= 200 && xhr.status < 300 && response.secure_url) {
          const videoUrl: string = response.secure_url;
          
          // Generate Cloudinary thumbnail poster from video first frame / transformation
          // Cloudinary allows requesting the poster frame by replacing video extension with .jpg
          const thumbnailUrl =
            response.thumbnail_url ||
            videoUrl.replace(/\.[a-zA-Z0-9]+$/, '.jpg');

          resolve({
            videoUrl,
            thumbnailUrl,
            duration: response.duration || 0,
            publicId: response.public_id,
            format: response.format || 'mp4',
          });
        } else {
          const errMsg =
            response.error?.message ||
            `Upload failed with status code ${xhr.status}. Check Cloudinary cloud name and unsigned preset.`;
          reject(new Error(errMsg));
        }
      } catch (err) {
        reject(new Error(`Failed to parse Cloudinary response: ${String(err)}`));
      }
    };

    xhr.onerror = () => {
      reject(new Error('Network error occurred while uploading video to Cloudinary. Please check your internet connection.'));
    };

    xhr.ontimeout = () => {
      reject(new Error('Video upload timed out. Please try again with a shorter video.'));
    };

    // 120s timeout for large video uploads
    xhr.timeout = 120000;

    xhr.send(formData);
  });
}
