import { Story } from '../types';

const STORIES_STORAGE_KEY = 'sogo_stories_cache';

const INITIAL_STORIES: Story[] = [
  {
    id: 'story_1',
    userId: 'user_2',
    user: {
      id: 'user_2',
      username: 'maya_lens',
      displayName: 'Maya Chen',
      avatarUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=300&auto=format&fit=crop&q=80',
    },
    mediaUrl: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&auto=format&fit=crop&q=80',
    createdAt: new Date(Date.now() - 2 * 3600000).toISOString(),
    hasSeen: false,
  },
  {
    id: 'story_2',
    userId: 'user_4',
    user: {
      id: 'user_4',
      username: 'sophia_travel',
      displayName: 'Sophia Laurent',
      avatarUrl: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=300&auto=format&fit=crop&q=80',
    },
    mediaUrl: 'https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?w=800&auto=format&fit=crop&q=80',
    createdAt: new Date(Date.now() - 5 * 3600000).toISOString(),
    hasSeen: false,
  },
  {
    id: 'story_3',
    userId: 'user_3',
    user: {
      id: 'user_3',
      username: 'alex_design',
      displayName: 'Alex Rivers',
      avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&auto=format&fit=crop&q=80',
    },
    mediaUrl: 'https://images.unsplash.com/photo-1513542789411-b6a5d4f31634?w=800&auto=format&fit=crop&q=80',
    createdAt: new Date(Date.now() - 8 * 3600000).toISOString(),
    hasSeen: true,
  },
  {
    id: 'story_4',
    userId: 'user_5',
    user: {
      id: 'user_5',
      username: 'kai_tokyo',
      displayName: 'Kai Sato',
      avatarUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=300&auto=format&fit=crop&q=80',
    },
    mediaUrl: 'https://images.unsplash.com/photo-1503899036084-c55cdd92da26?w=800&auto=format&fit=crop&q=80',
    createdAt: new Date(Date.now() - 11 * 3600000).toISOString(),
    hasSeen: false,
  }
];

function getStoredStories(): Story[] {
  try {
    const raw = localStorage.getItem(STORIES_STORAGE_KEY);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.error('Failed to parse stories from storage', e);
  }
  return INITIAL_STORIES;
}

function saveStories(stories: Story[]) {
  try {
    localStorage.setItem(STORIES_STORAGE_KEY, JSON.stringify(stories));
  } catch (e) {
    console.error('Failed to save stories to storage', e);
  }
}

export async function getActiveStories(): Promise<Story[]> {
  return getStoredStories();
}

export async function createStory(user: Story['user'], mediaUrl: string): Promise<Story> {
  const stories = getStoredStories();
  const newStory: Story = {
    id: `story_${Date.now()}`,
    userId: user.id,
    user,
    mediaUrl,
    createdAt: new Date().toISOString(),
    hasSeen: false,
  };
  const updated = [newStory, ...stories];
  saveStories(updated);
  return newStory;
}

export async function markStorySeen(storyId: string): Promise<void> {
  const stories = getStoredStories();
  const updated = stories.map((s) => (s.id === storyId ? { ...s, hasSeen: true } : s));
  saveStories(updated);
}
