import {
  collection,
  doc,
  getDocs,
  getDoc,
  setDoc,
  deleteDoc,
  updateDoc,
  increment,
  query,
  where,
  orderBy,
  limit,
  startAfter,
  DocumentSnapshot,
} from 'firebase/firestore';
import { db } from '../lib/firebase';
import { VideoPost, VideoComment } from '../types';

const VIDEOS_COLLECTION = 'videos';
const LOCAL_VIDEOS_CACHE_KEY = 'sogo_videos_cache';
const VIEWED_VIDEOS_SESSION_KEY = 'sogo_viewed_videos_session';

// Helper for session view tracking to avoid excessive Firestore writes
const sessionViewedIds = new Set<string>();

/**
 * Reads local cached videos (fallback & offline support).
 */
function getLocalVideos(): VideoPost[] {
  try {
    const raw = localStorage.getItem(LOCAL_VIDEOS_CACHE_KEY);
    if (raw) return JSON.parse(raw);
  } catch (err) {
    console.warn('Failed to read local videos cache', err);
  }
  return [];
}

/**
 * Saves videos to local cache.
 */
function saveLocalVideos(videos: VideoPost[]) {
  try {
    localStorage.setItem(LOCAL_VIDEOS_CACHE_KEY, JSON.stringify(videos));
  } catch (err) {
    console.warn('Failed to update local videos cache', err);
  }
}

/**
 * Fetches paginated videos from Firestore ordered by creation date descending.
 */
export async function getVideos(
  lastDocSnapshot?: DocumentSnapshot | null,
  pageSize = 8,
  currentUserId?: string
): Promise<{ videos: VideoPost[]; nextCursor: DocumentSnapshot | null }> {
  try {
    const videosRef = collection(db, VIDEOS_COLLECTION);
    let q = query(videosRef, orderBy('createdAt', 'desc'), limit(pageSize));

    if (lastDocSnapshot) {
      q = query(videosRef, orderBy('createdAt', 'desc'), startAfter(lastDocSnapshot), limit(pageSize));
    }

    const snapshot = await getDocs(q);
    const firestoreVideos: VideoPost[] = [];

    for (const d of snapshot.docs) {
      const data = d.data();
      const video: VideoPost = {
        id: d.id,
        userId: data.userId || '',
        user: data.user || {
          id: data.userId || '',
          username: 'user',
          displayName: 'Sogo User',
          avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300',
        },
        videoUrl: data.videoUrl || '',
        thumbnailUrl: data.thumbnailUrl || '',
        caption: data.caption || '',
        tags: data.tags || [],
        likesCount: Number(data.likesCount) || 0,
        commentsCount: Number(data.commentsCount) || 0,
        viewsCount: Number(data.viewsCount) || 0,
        duration: data.duration,
        createdAt: data.createdAt || new Date().toISOString(),
        isLiked: false,
      };

      // If user is authenticated, check if they liked this video
      if (currentUserId) {
        try {
          const likeDoc = await getDoc(doc(db, VIDEOS_COLLECTION, d.id, 'likes', currentUserId));
          video.isLiked = likeDoc.exists();
        } catch {
          video.isLiked = false;
        }
      }

      firestoreVideos.push(video);
    }

    const nextCursor = snapshot.docs.length >= pageSize ? snapshot.docs[snapshot.docs.length - 1] : null;

    // Cache videos locally
    if (!lastDocSnapshot && firestoreVideos.length > 0) {
      saveLocalVideos(firestoreVideos);
    }

    return {
      videos: firestoreVideos,
      nextCursor,
    };
  } catch (err) {
    console.warn('Firestore getVideos failed, using local cache fallback', err);
    const cached = getLocalVideos();
    return {
      videos: cached,
      nextCursor: null,
    };
  }
}

/**
 * Creates a new video document in Firestore after Cloudinary upload succeeds.
 */
export async function createVideo(
  videoData: Omit<VideoPost, 'id' | 'likesCount' | 'commentsCount' | 'viewsCount' | 'isLiked' | 'createdAt'>
): Promise<VideoPost> {
  const newVideoId = `vid_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
  const nowIso = new Date().toISOString();

  const fullVideo: VideoPost = {
    ...videoData,
    id: newVideoId,
    likesCount: 0,
    commentsCount: 0,
    viewsCount: 0,
    isLiked: false,
    createdAt: nowIso,
  };

  try {
    const docRef = doc(db, VIDEOS_COLLECTION, newVideoId);
    await setDoc(docRef, {
      userId: fullVideo.userId,
      user: fullVideo.user,
      videoUrl: fullVideo.videoUrl,
      thumbnailUrl: fullVideo.thumbnailUrl,
      caption: fullVideo.caption,
      tags: fullVideo.tags || [],
      likesCount: 0,
      commentsCount: 0,
      viewsCount: 0,
      duration: fullVideo.duration || 0,
      createdAt: nowIso,
    });
  } catch (err) {
    console.error('Failed to write video document to Firestore', err);
    // Even if firestore threw an error (e.g. offline), we preserve in local cache
  }

  // Update local cache so it appears immediately
  const existing = getLocalVideos();
  saveLocalVideos([fullVideo, ...existing]);

  return fullVideo;
}

/**
 * Toggles a like on a video in Firestore:
 * Writes to subcollection `videos/{videoId}/likes/{userId}` and updates `likesCount`.
 */
export async function toggleLikeVideo(
  videoId: string,
  userId: string
): Promise<{ isLiked: boolean; likesCount: number }> {
  try {
    const videoRef = doc(db, VIDEOS_COLLECTION, videoId);
    const likeRef = doc(db, VIDEOS_COLLECTION, videoId, 'likes', userId);
    const likeSnap = await getDoc(likeRef);

    const videoSnap = await getDoc(videoRef);
    const currentLikes = videoSnap.exists() ? Number(videoSnap.data().likesCount) || 0 : 0;

    if (likeSnap.exists()) {
      // Unlike
      await deleteDoc(likeRef);
      const nextCount = Math.max(0, currentLikes - 1);
      await updateDoc(videoRef, { likesCount: increment(-1) });
      return { isLiked: false, likesCount: nextCount };
    } else {
      // Like
      await setDoc(likeRef, { userId, likedAt: new Date().toISOString() });
      const nextCount = currentLikes + 1;
      await updateDoc(videoRef, { likesCount: increment(1) });
      return { isLiked: true, likesCount: nextCount };
    }
  } catch (err) {
    console.warn('Firestore toggleLikeVideo failed, updating locally', err);
    return { isLiked: true, likesCount: 1 };
  }
}

/**
 * Increments the view count for a video conservatively.
 * Avoids spamming by checking session-viewed cache first.
 */
export async function incrementVideoViews(videoId: string): Promise<void> {
  if (sessionViewedIds.has(videoId)) {
    return; // Already counted for this session
  }
  sessionViewedIds.add(videoId);

  try {
    const videoRef = doc(db, VIDEOS_COLLECTION, videoId);
    await updateDoc(videoRef, {
      viewsCount: increment(1),
    });
  } catch (err) {
    console.warn('Could not increment video views in Firestore', err);
  }
}

/**
 * Retrieves comments for a video from `videos/{videoId}/comments`.
 */
export async function getVideoComments(videoId: string): Promise<VideoComment[]> {
  try {
    const commentsRef = collection(db, VIDEOS_COLLECTION, videoId, 'comments');
    const q = query(commentsRef, orderBy('createdAt', 'asc'));
    const snapshot = await getDocs(q);

    return snapshot.docs.map((d) => {
      const data = d.data();
      return {
        id: d.id,
        videoId,
        userId: data.userId || '',
        user: data.user || {
          id: data.userId || '',
          username: 'user',
          displayName: 'User',
          avatarUrl: '',
        },
        text: data.text || '',
        createdAt: data.createdAt || new Date().toISOString(),
      };
    });
  } catch (err) {
    console.warn('Failed to load video comments from Firestore', err);
    return [];
  }
}

/**
 * Adds a comment to a video in `videos/{videoId}/comments` and increments `commentsCount`.
 */
export async function addVideoComment(
  videoId: string,
  user: VideoComment['user'],
  text: string
): Promise<VideoComment> {
  const commentId = `vcom_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
  const nowIso = new Date().toISOString();

  const comment: VideoComment = {
    id: commentId,
    videoId,
    userId: user.id,
    user,
    text: text.trim(),
    createdAt: nowIso,
  };

  try {
    const commentRef = doc(db, VIDEOS_COLLECTION, videoId, 'comments', commentId);
    await setDoc(commentRef, {
      id: commentId,
      videoId,
      userId: user.id,
      user,
      text: comment.text,
      createdAt: nowIso,
    });

    const videoRef = doc(db, VIDEOS_COLLECTION, videoId);
    await updateDoc(videoRef, {
      commentsCount: increment(1),
    });
  } catch (err) {
    console.warn('Could not save comment to Firestore', err);
  }

  return comment;
}

/**
 * Retrieves all videos created by a specific user (for the Profile screen).
 */
export async function getUserVideos(userId: string): Promise<VideoPost[]> {
  try {
    const videosRef = collection(db, VIDEOS_COLLECTION);
    const q = query(videosRef, where('userId', '==', userId), orderBy('createdAt', 'desc'));
    const snapshot = await getDocs(q);

    return snapshot.docs.map((d) => {
      const data = d.data();
      return {
        id: d.id,
        userId: data.userId,
        user: data.user,
        videoUrl: data.videoUrl,
        thumbnailUrl: data.thumbnailUrl,
        caption: data.caption,
        tags: data.tags || [],
        likesCount: Number(data.likesCount) || 0,
        commentsCount: Number(data.commentsCount) || 0,
        viewsCount: Number(data.viewsCount) || 0,
        duration: data.duration,
        createdAt: data.createdAt,
      };
    });
  } catch (err) {
    console.warn('Failed to query user videos from Firestore, checking local cache', err);
    const cached = getLocalVideos();
    return cached.filter((v) => v.userId === userId);
  }
}
