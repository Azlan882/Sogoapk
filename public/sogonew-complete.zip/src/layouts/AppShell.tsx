import React from 'react';
import { Header } from '../components/Header';
import { BottomNavigation } from '../components/BottomNavigation';
import { ActiveTab } from '../types';

export interface AppShellProps {
  children: React.ReactNode;
  currentTab: ActiveTab;
  onTabChange: (tab: ActiveTab) => void;
  unreadNotificationsCount?: number;
}

export const AppShell: React.FC<AppShellProps> = ({
  children,
  currentTab,
  onTabChange,
  unreadNotificationsCount = 2,
}) => {
  const isVideoFeed = currentTab === 'videos';

  return (
    <div className={`min-h-screen flex flex-col bg-[#0B0F1A] text-slate-200 ${isVideoFeed ? 'pb-16' : 'pb-20 sm:pb-24'}`}>
      {/* Top Header (omitted in immersive Reels view where Reels has its own overlay header) */}
      {!isVideoFeed && (
        <Header
          currentTab={currentTab}
          onTabChange={onTabChange}
          unreadNotificationsCount={unreadNotificationsCount}
        />
      )}

      {/* Main Content Area */}
      <main
        className={
          isVideoFeed
            ? 'flex-1 w-full max-w-md mx-auto p-0 relative overflow-hidden'
            : 'flex-1 w-full max-w-2xl mx-auto px-3 sm:px-4 py-4 sm:py-6'
        }
      >
        {children}
      </main>

      {/* Persistent Bottom Bar */}
      <BottomNavigation
        currentTab={currentTab}
        onTabChange={onTabChange}
      />
    </div>
  );
};
