import { initializeApp, getApps, type FirebaseApp } from 'firebase/app';
import { getAuth, type Auth } from 'firebase/auth';
import { getFirestore, type Firestore } from 'firebase/firestore';

// Production Firebase Web configuration for project sogo-e5ea9
export const firebaseConfig = {
  apiKey: (
    import.meta.env.VITE_FIREBASE_API_KEY ||
    (typeof process !== 'undefined' ? process.env?.VITE_FIREBASE_API_KEY || process.env?.FIREBASE_API_KEY : '') ||
    'AIzaSyA7XXZaXGrs6g4La5lkd3Vil8AJSUXTlek'
  ).trim(),
  authDomain: (
    import.meta.env.VITE_FIREBASE_AUTH_DOMAIN ||
    (typeof process !== 'undefined' ? process.env?.VITE_FIREBASE_AUTH_DOMAIN || process.env?.FIREBASE_AUTH_DOMAIN : '') ||
    'sogo-e5ea9.firebaseapp.com'
  ).trim(),
  projectId: (
    import.meta.env.VITE_FIREBASE_PROJECT_ID ||
    (typeof process !== 'undefined' ? process.env?.VITE_FIREBASE_PROJECT_ID || process.env?.FIREBASE_PROJECT_ID : '') ||
    'sogo-e5ea9'
  ).trim(),
  storageBucket: (
    import.meta.env.VITE_FIREBASE_STORAGE_BUCKET ||
    (typeof process !== 'undefined' ? process.env?.VITE_FIREBASE_STORAGE_BUCKET || process.env?.FIREBASE_STORAGE_BUCKET : '') ||
    'sogo-e5ea9.firebasestorage.app'
  ).trim(),
  messagingSenderId: (
    import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID ||
    (typeof process !== 'undefined' ? process.env?.VITE_FIREBASE_MESSAGING_SENDER_ID || process.env?.FIREBASE_MESSAGING_SENDER_ID : '') ||
    '1035132864845'
  ).trim(),
  appId: (
    import.meta.env.VITE_FIREBASE_APP_ID ||
    (typeof process !== 'undefined' ? process.env?.VITE_FIREBASE_APP_ID || process.env?.FIREBASE_APP_ID : '') ||
    '1:1035132864845:web:6508bc026762f4887f8f04'
  ).trim(),
  measurementId: (
    import.meta.env.VITE_FIREBASE_MEASUREMENT_ID ||
    (typeof process !== 'undefined' ? process.env?.VITE_FIREBASE_MEASUREMENT_ID || process.env?.FIREBASE_MEASUREMENT_ID : '') ||
    'G-7FCKN828JC'
  ).trim(),
};

export const isFirebaseConfigured = true;

// OAuth 2.0 Web Client ID for Google Sign-In (Firebase & Credential Manager)
export const GOOGLE_WEB_CLIENT_ID = (
  import.meta.env.VITE_GOOGLE_WEB_CLIENT_ID ||
  '1035132864845-ulhcdqfeknujp5mc1naj6vhrujqc828t.apps.googleusercontent.com'
).trim();

const app: FirebaseApp = !getApps().length ? initializeApp(firebaseConfig) : getApps()[0];
const auth: Auth = getAuth(app);
const db: Firestore = getFirestore(app);

export { app, auth, db };
